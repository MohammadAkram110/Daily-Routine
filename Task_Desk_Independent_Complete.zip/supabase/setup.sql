-- Run once in a NEW Supabase project's SQL editor. Re-running is supported.
-- Each signed-in user can access only their own rows and private file folder.
begin;

create table if not exists public.taskdesk_accounts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  document jsonb not null,
  revision bigint not null default 0 check (revision >= 0),
  updated_at bigint not null
);
create table if not exists public.taskdesk_backups (
  id text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  document jsonb not null,
  label text not null,
  created_at bigint not null,
  primary key (user_id,id)
);
create index if not exists taskdesk_backups_recent on public.taskdesk_backups(user_id,created_at desc);
create table if not exists public.taskdesk_files (
  id text not null check (id ~ '^[-a-zA-Z0-9_]{8,80}$'),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(name) between 1 and 255),
  type text not null check (length(type) <= 150),
  size bigint not null check (size between 0 and 10000000),
  created_at bigint not null,
  primary key(user_id,id)
);

alter table public.taskdesk_accounts enable row level security;
alter table public.taskdesk_backups enable row level security;
alter table public.taskdesk_files enable row level security;
revoke all on public.taskdesk_accounts,public.taskdesk_backups,public.taskdesk_files from anon;
grant select,insert,update,delete on public.taskdesk_accounts,public.taskdesk_backups,public.taskdesk_files to authenticated;

drop policy if exists taskdesk_own_account on public.taskdesk_accounts;
create policy taskdesk_own_account on public.taskdesk_accounts for all to authenticated
  using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
drop policy if exists taskdesk_own_backups on public.taskdesk_backups;
create policy taskdesk_own_backups on public.taskdesk_backups for all to authenticated
  using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
drop policy if exists taskdesk_own_files on public.taskdesk_files;
create policy taskdesk_own_files on public.taskdesk_files for all to authenticated
  using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

create or replace function public.taskdesk_save_state(p_document jsonb,p_expected_revision bigint)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
  v_user uuid:=auth.uid();
  v_previous public.taskdesk_accounts%rowtype;
  v_revision bigint;
  v_time bigint:=floor(extract(epoch from clock_timestamp())*1000)::bigint;
  v_daily text;
begin
  if v_user is null then raise sqlstate 'PT401' using message='Sign in first.'; end if;
  if p_document is null or p_document->>'schemaVersion' is distinct from '4'
    or jsonb_typeof(p_document->'tasks') is distinct from 'array'
    or jsonb_typeof(p_document->'roster') is distinct from 'array'
    or jsonb_typeof(p_document->'reports') is distinct from 'array'
    or jsonb_typeof(p_document->'settings') is distinct from 'object'
    or octet_length(p_document::text)>1500000 then
    raise sqlstate 'PT400' using message='Invalid or oversized Task Desk document.';
  end if;
  -- Serialize only this user's saves, including the first-ever insert.
  perform pg_advisory_xact_lock(hashtextextended(v_user::text,0));
  select * into v_previous from public.taskdesk_accounts where user_id=v_user for update;
  if p_expected_revision is null or p_expected_revision<0 or coalesce(v_previous.revision,0)<>p_expected_revision then
    raise sqlstate 'PT409' using message='Another device saved. Merge and retry.';
  end if;
  if v_previous.user_id is not null and v_previous.document is distinct from p_document then
    v_daily:='daily:'||to_char(timezone('Asia/Karachi',now()),'YYYY-MM-DD');
    insert into public.taskdesk_backups(id,user_id,document,label,created_at)
      values(v_daily,v_user,v_previous.document,'Automatic daily copy',v_time)
      on conflict(user_id,id) do nothing;
  end if;
  v_revision:=coalesce(v_previous.revision,0)+1;
  insert into public.taskdesk_accounts(user_id,document,revision,updated_at)
    values(v_user,p_document,v_revision,v_time)
    on conflict(user_id) do update set document=excluded.document,revision=excluded.revision,updated_at=excluded.updated_at;
  delete from public.taskdesk_backups where user_id=v_user and id not in
    (select id from public.taskdesk_backups where user_id=v_user order by created_at desc,id desc limit 30);
  return jsonb_build_object('document',p_document,'revision',v_revision);
end;
$$;
revoke all on function public.taskdesk_save_state(jsonb,bigint) from public,anon;
grant execute on function public.taskdesk_save_state(jsonb,bigint) to authenticated;

create or replace function public.taskdesk_snapshot(p_label text default 'Saved copy')
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare
  v_user uuid:=auth.uid();v_id text:=gen_random_uuid()::text;
  v_document jsonb;v_time bigint:=floor(extract(epoch from clock_timestamp())*1000)::bigint;
begin
  if v_user is null then raise sqlstate 'PT401' using message='Sign in first.'; end if;
  select document into v_document from public.taskdesk_accounts where user_id=v_user;
  if not found then raise sqlstate 'PT409' using message='Sync your list first.'; end if;
  insert into public.taskdesk_backups(id,user_id,document,label,created_at)
    values(v_id,v_user,v_document,left(coalesce(p_label,'Saved copy'),100),v_time);
  delete from public.taskdesk_backups where user_id=v_user and id not in
    (select id from public.taskdesk_backups where user_id=v_user order by created_at desc,id desc limit 30);
  return jsonb_build_object('id',v_id,'saved',true);
end;
$$;
revoke all on function public.taskdesk_snapshot(text) from public,anon;
grant execute on function public.taskdesk_snapshot(text) to authenticated;

insert into storage.buckets(id,name,public,file_size_limit)
  values('taskdesk-files','taskdesk-files',false,10000000)
  on conflict(id) do update set public=false,file_size_limit=10000000;
drop policy if exists taskdesk_private_objects on storage.objects;
create policy taskdesk_private_objects on storage.objects for all to authenticated
  using (bucket_id='taskdesk-files' and (storage.foldername(name))[1]=(select auth.uid()::text))
  with check (bucket_id='taskdesk-files' and (storage.foldername(name))[1]=(select auth.uid()::text));

commit;
