# Bring your current Task Desk data

The ZIP contains the application and database setup, not the data from your
existing online account. Nothing in the export automatically changes that site.

1. Open your existing Task Desk and sign in. Let it finish syncing on the
   device that has your latest changes.
2. Open **Backup & export**. Download its **JSON backup** and **attachment
   archive**. Excel is useful for reading/sharing, but JSON is the restore file.
3. Set up the new independent website and cloud project using SETUP_SYNC.md.
4. Sign in on the new site, open Backup & export and use the restore/import
   JSON control. Review the confirmation before restoring the backup.
5. Restore the attachment archive too. JSON stores attachment information,
   while the archive contains the actual files.
6. Confirm tasks, order, due dates, roster and shift end reports. Trigger sync
   and wait for the sync confirmation. Large attachment sets take longer.
7. Open the same NEW URL on mobile with the same email/password. Check the
   tasks and reports, and open an attachment to verify the transfer.
8. Keep the downloaded backups until you have verified both devices.

The first sign-in on a browser merges its device-only list into that account.
Sign-out keeps a per-account local cache for later sign-in. Restoring a saved
copy is a deliberate list restore; review its summary before proceeding.

The old site's reminder automation is separate and does not start checking the
new independent site's database. This package provides in-page reminders only.
No messages or reports are sent automatically; copy or download a report and
communicate it using your normal written/verbal handover process.
