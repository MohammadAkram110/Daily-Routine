#!/usr/bin/env python3
"""Build the offline file and portable ZIPs; Python standard library only."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/'website'
DIST=ROOT.parent
OFFLINE_NAME='My_Task_Desk_Offline.html'
OUTER='Task_Desk_Independent_Complete.zip'

source=(WEB/'index.html').read_text()
# Inline the app source so double-click use needs no network or sidecar files.
def style(match):
    path=WEB/match.group(1).split('?')[0]
    return '<style>\n'+path.read_text()+'\n</style>'
def script(match):
    path=WEB/match.group(1).split('?')[0]
    code=path.read_text()
    if path.name=='config.js':
        code='window.TASK_DESK_CONFIG = {supabaseUrl:"",supabaseKey:""};'
    return '<script>\n'+re.sub(r'</script',r'<\\/script',code,flags=re.I)+'\n</script>'
# Execute inline app scripts after the DOM has been parsed.
source=re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/?>',style,source)
inline_scripts=[]
def collect(match):
    inline_scripts.append(script(match));return ''
source=re.sub(r'<script src="([^"]+)" defer></script>',collect,source)
source=re.sub(r'<link rel="manifest"[^>]*>','',source)
source=source.replace('</body>','\n'+'\n'.join(inline_scripts)+'\n</body>')
source=source.replace('Your independent task desk:','Your offline task desk:')
(WEB/'downloads').mkdir(exist_ok=True)
(WEB/'downloads'/OFFLINE_NAME).write_text(source)
(ROOT/OFFLINE_NAME).write_text(source)

class Assets(HTMLParser):
    def handle_starttag(self,tag,attrs):
        fields=dict(attrs)
        url=fields.get('src') if tag=='script' else fields.get('href') if tag=='link' else None
        if url and not url.startswith(('data:','https:','http:','#')):
            assert (WEB/url.split('?')[0]).is_file(),f'Missing asset: {url}'
Assets().feed((WEB/'index.html').read_text())
assert 'chatgpt.site' not in source
assert json.loads((WEB/'manifest.webmanifest').read_text())['start_url']=='./'
# The offline file must remain local even when hosted for download.
assert 'window.TASK_DESK_CONFIG = {supabaseUrl:"",supabaseKey:""};' in source

upload=ROOT/'Cloudflare_Upload.zip'
with zipfile.ZipFile(upload,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(WEB.rglob('*')):
        if path.is_file():archive.write(path,path.relative_to(WEB))
with zipfile.ZipFile(upload) as archive:
    assert 'index.html' in archive.namelist()
    assert not archive.testzip()

# File checksums make later deployment/source comparison easy.
files=[p for p in ROOT.rglob('*') if p.is_file() and not any(part.startswith('.') or part in {'outputs','node_modules'} for part in p.relative_to(ROOT).parts) and p.name!='SHA256SUMS.txt']
(ROOT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in sorted(files)))
complete=DIST/OUTER
with zipfile.ZipFile(complete,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(ROOT.rglob('*')):
        relative=path.relative_to(ROOT)
        if path.is_file() and not any(part.startswith('.') or part in {'outputs','node_modules'} for part in relative.parts):archive.write(path,relative)
with zipfile.ZipFile(complete) as archive:
    assert not archive.testzip()
    assert all(name in archive.namelist() for name in ['README_START_HERE.txt','Cloudflare_Upload.zip',OFFLINE_NAME,'website/index.html','supabase/setup.sql'])
print(f'{complete} ({complete.stat().st_size:,} bytes)')
