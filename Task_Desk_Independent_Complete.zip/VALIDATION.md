# Validation

Automated checks cover task/shift report validation, manual reordering,
sideways status changes, recurring tasks, Pakistan time, offline merges,
Excel structure, Supabase transport, concurrent revision retries, session
refresh, account-switch isolation, private attachment routes and backups.

Run `npm test` with Node.js. No dependencies need installing.

All 29 automated tests passed. JavaScript syntax and ZIP integrity checks passed.
The local browser preview verified task creation, saved order after reload,
sideways status movement, the cloud connection panel, and shift report draft
saving with a written preview. Test examples are not included as user data.
The code is delivered with blank cloud settings. Supabase transport tests use
a mock service: a live deployment, your SQL execution, authentication account,
row-level-security policies and laptop/phone transfer must be verified against
your own project using the setup guide. No live cloud configuration is implied.

`python3 tools/package.py` verifies local asset references and builds the
standalone HTML, the website upload ZIP and the complete package. It includes
no account passwords, service tokens, previous user data or server secrets.
