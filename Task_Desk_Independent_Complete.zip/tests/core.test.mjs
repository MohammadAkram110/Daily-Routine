import {test} from 'node:test';
import assert from 'node:assert/strict';
import {writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import '../website/core.js';
const C=globalThis.TaskDeskCore;
const at=(date,time='12:00')=>C.fromInputs(date,time);
const make=(id,order=0,data={})=>C.freshTask({id,text:id,order,createdAt:100,updatedAt:100,...data});
const state=tasks=>({schemaVersion:2,tasks});

test('old tasks migrate in original order without inventing completion dates',()=>{
 const s=C.normalizeState([{id:'a',text:'First',completed:false,createdAt:100},{id:'b',text:'Second',completed:true,createdAt:110}]);
 assert.deepEqual(C.active(s.tasks).map(t=>t.id),['a','b']);assert.equal(s.tasks[1].status,'completed');assert.equal(s.tasks[1].completedAt,null);
});
test('backup validation rejects duplicate IDs and malformed records before restore',()=>{
 assert.throws(()=>C.normalizeState(state([make('a'),make('a')])));assert.throws(()=>C.normalizeState(state([make('a',0,{dueAt:'tomorrow'})])));assert.throws(()=>C.normalizeState(state([make('a',0,{repeat:{every:0,unit:'day',from:'schedule'}})])));
});
test('manual order moves above, below, and stays the same after priority changes',()=>{
 let s=state([make('a',0),make('b',1),make('c',2)]);s=C.reorderTask(s,'c','a',false,null,200);assert.deepEqual(C.active(s.tasks).map(t=>t.id),['c','a','b']);s=C.reorderTask(s,'c','b',true,null,201);assert.deepEqual(C.active(s.tasks).map(t=>t.id),['a','b','c']);s.tasks[1].priority='critical';assert.deepEqual(C.active(s.tasks).map(t=>t.id),['a','b','c']);
});
test('sideways movement changes status and creates one next recurring occurrence',()=>{
 const t=make('repeat',0,{dueAt:at('2026-10-30'),repeat:{every:1,unit:'day',from:'schedule',anchorDay:30}});let s=state([t]);s=C.reorderTask(s,t.id,null,true,'completed',at('2026-10-30','13:00'));assert.equal(s.tasks[0].status,'completed');assert.equal(s.tasks.length,2);s=C.changeStatus(s,t.id,'pending',at('2026-10-30','13:01'));s=C.changeStatus(s,t.id,'completed',at('2026-10-30','13:02'));assert.equal(s.tasks.length,2);assert.equal(s.tasks[1].status,'pending');
});
test('month-end schedules return to their anchor after a short month',()=>{
 let t=make('m',0,{dueAt:at('2027-01-31'),repeat:{every:1,unit:'month',from:'schedule',anchorDay:31}});let next=C.nextDueAt(t,at('2027-01-31','13:00'));assert.equal(C.dateInput(next),'2027-02-28');t={...t,dueAt:next};assert.equal(C.dateInput(C.nextDueAt(t,at('2027-02-28','13:00'))),'2027-03-31');
});
test('fixed schedules skip missed dates while completion-based intervals retain completion time',()=>{
 const t=make('daily',0,{dueAt:at('2026-10-01','06:00'),repeat:{every:1,unit:'day',from:'schedule',anchorDay:1}});assert.equal(C.formatDate(C.nextDueAt(t,at('2026-10-30','14:00')),true),'31-Oct-2026 · 06:00');const c={...t,repeat:{every:2,unit:'day',from:'completion'}};assert.equal(C.formatDate(C.nextDueAt(c,at('2026-10-30','14:07')),true),'01-Nov-2026 · 14:07');
});
test('leap-year yearly repeat clamps 29 February safely',()=>{const t=make('y',0,{dueAt:at('2028-02-29'),repeat:{every:1,unit:'year',from:'schedule',anchorDay:29}});assert.equal(C.dateInput(C.nextDueAt(t,at('2028-02-29','13:00'))),'2029-02-28');});
test('offline deletion wins over older edits, while concurrent new tasks both survive',()=>{
 const a=make('a',0),deleted={...a,deleted:true,updatedAt:200};const left=state([deleted,make('b',1)]),right=state([{...a,text:'Old edit',updatedAt:150},make('c',2)]);const merged=C.mergeStates(left,right);assert.equal(merged.tasks.find(t=>t.id==='a').deleted,true);assert.deepEqual(C.active(merged.tasks).map(t=>t.id),['b','c']);assert.deepEqual(C.mergeStates(left,right),C.mergeStates(right,left));
});
test('equal-clock deletions cannot be resurrected by an offline copy',()=>{const t=make('a');assert.equal(C.mergeStates(state([t]),state([{...t,deleted:true}])).tasks[0].deleted,true);});
test('Pakistan date/time entry is independent of the machine timezone',()=>{assert.equal(new Date(at('2026-10-30','22:00')).toISOString(),'2026-10-30T17:00:00.000Z');assert.equal(C.formatDate(at('2026-10-30','22:00'),true),'30-Oct-2026 · 22:00');});
test('xlsx export contains actual ZIP/OpenXML and preserves formula-like text',()=>{
 const t=make('export',0,{text:'=SUM(A1:A2) <tag> & notes',closingComment:'Checked',history:[{at:at('2026-10-30'),action:'Completed',note:'Done'}]});const bytes=C.makeXlsx(state([t]));assert.equal(new DataView(bytes.buffer).getUint32(0,true),0x04034b50);mkdirSync('outputs',{recursive:true});writeFileSync(resolve('outputs/taskdesk-export-test.xlsx'),bytes);
});
