import {test} from 'node:test';
import assert from 'node:assert/strict';
import '../website/core.js';
import '../website/cloud.js';
const C=globalThis.TaskDeskCore,{createClient,checkConfig}=globalThis.TaskDeskCloudFactory;
const config={supabaseUrl:'https://taskdesk-test.supabase.co',supabaseKey:'sb_publishable_example_public_test'};
const empty=()=>C.normalizeState({schemaVersion:4,tasks:[]});
const doc=(id,at=100)=>C.normalizeState({schemaVersion:4,tasks:[C.freshTask({id,text:id,createdAt:at,updatedAt:at})]});
const ok=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)};};
const payload=(id='alice',expire=3600)=>({access_token:'access-'+id,refresh_token:'refresh-'+id,expires_in:expire,user:{id,email:id+'@example.test'}});
function backend(){
 const users=new Map(),files=new Map(),objects=new Map(),calls=[];let conflict=null,refreshes=0,fail=null,gate=null;
 async function fetch(url,options={}){
  const u=new URL(url),path=u.pathname,headers=new Headers(options.headers),method=options.method??'GET';calls.push({url,options,headers});
  assert.equal(u.origin,config.supabaseUrl);assert.equal(options.redirect,'error');
  if(path==='/auth/v1/token'){
   if(u.search.includes('refresh_token')){refreshes++;return ok(payload(JSON.parse(options.body).refresh_token.replace('refresh-','')));}
   return ok(payload(JSON.parse(options.body).email.split('@')[0]));
  }
  if(path==='/auth/v1/logout')return ok({});
  const id=(headers.get('authorization')??'').replace('Bearer access-','');assert(id);
  if(gate){const wait=gate;gate=null;await wait;}
  if(fail)return ok(fail.body,fail.status);
  const entry=()=>users.get(id)??{document:empty(),revision:0,backups:[]};
  if(path==='/rest/v1/taskdesk_accounts'){
    assert.equal(u.searchParams.get('user_id'),'eq.'+id);
    const e=users.get(id);return ok(e?[{document:e.document,revision:e.revision}]:[]);
  }
  if(path==='/rest/v1/rpc/taskdesk_save_state'){
    const body=JSON.parse(options.body),e=entry();if(conflict){conflict(e);conflict=null;users.set(id,e);}
    if(body.p_expected_revision!==e.revision)return ok({code:'PT409',message:'Concurrent save'},409);
    e.document=body.p_document;e.revision++;users.set(id,e);return ok({document:e.document,revision:e.revision});
  }
  if(path==='/rest/v1/rpc/taskdesk_snapshot'){const e=entry(),copy={id:'copy1',document:e.document,label:'Saved copy',created_at:1000};e.backups.push(copy);users.set(id,e);return ok({saved:true,id:copy.id});}
  if(path==='/rest/v1/taskdesk_backups'){const e=entry(),filter=u.searchParams.get('id');return ok(filter?e.backups.filter(x=>'eq.'+x.id===filter):e.backups);}
  if(path==='/rest/v1/taskdesk_files'){
    if(method==='POST'){const f=JSON.parse(options.body);assert.equal(f.user_id,id);files.set(id+'/'+f.id,f);return ok([f],201);}
    return ok([...files.values()].filter(f=>f.user_id===id&&u.searchParams.get('id')==='eq.'+f.id));
  }
  if(path.startsWith('/storage/v1/object/taskdesk-files/')){
    const object=path.slice('/storage/v1/object/taskdesk-files/'.length);assert(object.startsWith(id+'/'));
    if(method==='POST'){if(objects.has(object))return ok({},409);objects.set(object,options.body);return ok({},200);}
    const blob=objects.get(object);return blob?new Response(blob,{headers:{'content-length':String(blob.size)}}):ok({},404);
  }
  throw Error('Unexpected mock request: '+path);
 }
 return {fetch,calls,users,files,objects,get refreshes(){return refreshes;},set conflict(f){conflict=f;},set fail(f){fail=f;},set gate(f){gate=f;}};
}
async function client(b,id='alice',store=storage(),now){const c=createClient({config,core:C,fetch:b.fetch,storage:store,now});await c.signIn(id+'@example.test','test-password');return c;}
const save=(c,d)=>c.request('/api/state',{method:'POST',body:JSON.stringify(d)});

test('local mode needs no service; connection checks reject non-public keys and other origins',async()=>{
 const c=createClient({core:C,storage:storage()});assert.equal(c.configured,false);assert.equal((await c.request('/api/state')).status,401);
 for(const input of [{...config,supabaseUrl:'http://taskdesk-test.supabase.co'},{...config,supabaseUrl:'https://supabase.co.evil.test'},{...config,supabaseKey:'sb_secret_never'},{...config,supabaseUrl:config.supabaseUrl+'/path'}])assert.throws(()=>checkConfig(input));
 const jwt=role=>btoa('{"alg":"HS256"}')+'.'+btoa(JSON.stringify({role}))+'.signature';assert.throws(()=>checkConfig({...config,supabaseKey:jwt('service_role')}));assert.equal(checkConfig({...config,supabaseKey:jwt('anon')}).supabaseUrl,config.supabaseUrl);
});
test('two devices merge offline additions and deletions through revisioned saves',async()=>{
 const b=backend(),a=await client(b),second=await client(b);assert.equal((await save(a,doc('a'))).status,200);
 assert.equal((await save(second,doc('b'))).status,200);
 let state=(await (await a.request('/api/state')).json()).document;assert.deepEqual(state.tasks.map(t=>t.id).sort(),['a','b']);
 state={...state,tasks:state.tasks.map(t=>t.id==='a'?{...t,deleted:true,updatedAt:200}:t)};await save(a,state);await save(second,doc('a',100));
 const final=(await (await second.request('/api/state')).json()).document;assert(final.tasks.find(t=>t.id==='a').deleted);assert.equal(C.active(final.tasks).length,1);
});
test('revision conflicts re-read and merge the newer remote list',async()=>{
 const b=backend(),a=await client(b);b.conflict=e=>{e.document=doc('other');e.revision++;};
 const r=await save(a,doc('mine'));assert.equal(r.status,200);assert.deepEqual((await r.json()).document.tasks.map(t=>t.id).sort(),['mine','other']);
 assert.equal(b.calls.filter(x=>x.url.includes('rpc/taskdesk_save_state')).length,2);
});
test('separate account records never merge across users',async()=>{
 const b=backend(),a=await client(b),bob=await client(b,'bob');await save(a,doc('private-alice'));await save(bob,doc('private-bob'));
 assert.equal((await (await bob.request('/api/state')).json()).document.tasks[0].text,'private-bob');
 assert.equal((await (await a.request('/api/state')).json()).document.tasks[0].text,'private-alice');
});
test('an account change during a save aborts it before writing to another user',async()=>{
 const b=backend(),a=await client(b);let release;b.gate=new Promise(resolve=>{release=resolve;});
 const writing=save(a,doc('alice-only'));await new Promise(resolve=>setTimeout(resolve,0));await a.signIn('bob@example.test','test-password');release();
 assert.equal((await writing).status,401);assert.equal(b.users.has('bob'),false);
});
test('refresh runs once for concurrent requests; signout removes cached session',async()=>{
 const b=backend(),store=storage();let now=0;const a=await client(b,'alice',store,()=>now);now=3590000;
 const results=await Promise.all([a.request('/api/state'),a.request('/api/state')]);assert(results.every(r=>r.ok));assert.equal(b.refreshes,1);
 await a.signOut();assert.equal(a.user,null);assert.equal((await a.request('/api/state')).status,401);
 const restored=createClient({config,core:C,fetch:b.fetch,storage:store});assert.equal(restored.user,null);
});
test('logout during token refresh cannot restore the old session',async()=>{
 const b=backend(),store=storage();let now=0;const a=await client(b,'alice',store,()=>now),old=b.fetch;let release,started;
 const start=new Promise(r=>started=r);b.fetch=async(url,options)=>{if(url.includes('grant_type=refresh_token')){started();await new Promise(r=>release=r);}return old(url,options);};
 // A second client loads the cached session and the gated fetch.
 const c=createClient({config,core:C,fetch:b.fetch,storage:store,now:()=>now});now=3590000;const pending=c.request('/api/state');await start;await c.signOut();release();
 assert.equal((await pending).status,401);assert.equal(c.user,null);
});
test('cloud backups save and restore the exact document',async()=>{
 const b=backend(),a=await client(b);await save(a,doc('remember'));assert((await a.request('/api/backups',{method:'POST'})).ok);
 assert.equal((await (await a.request('/api/backups')).json()).backups.length,1);
 const restored=await (await a.request('/api/backups/copy1')).json();assert.equal(restored.document.tasks[0].text,'remember');
});
test('private attachment upload/download preserves bytes; other account cannot read it',async()=>{
 const b=backend(),a=await client(b),bob=await client(b,'bob'),form=new FormData();form.append('id','attachment_123');form.append('file',new Blob(['shift notes'],{type:'text/plain'}),'notes.txt');
 assert.equal((await a.request('/api/files',{method:'POST',body:form})).status,200);
 const response=await a.request('/api/files/attachment_123');assert.equal(await response.text(),'shift notes');assert.match(response.headers.get('content-disposition'),/^attachment/);
 assert.equal((await bob.request('/api/files/attachment_123')).status,404);assert.equal((await a.request('/api/files/..%2Fevil')).status,404);
});
test('schema failures give actionable setup errors while retaining local caller data',async()=>{
 const b=backend(),a=await client(b),local=doc('safe');b.fail={status:404,body:{code:'PGRST205'}};
 const response=await save(a,local);assert.equal(response.status,404);assert.match((await response.json()).error,/supabase\/setup.sql/);assert.equal(local.tasks[0].text,'safe');
});
