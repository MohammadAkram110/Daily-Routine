import {test} from 'node:test';
import assert from 'node:assert/strict';
import '../website/core.js';
const C=globalThis.TaskDeskCore;
const state=(reports=[],tasks=[])=>C.normalizeState({schemaVersion:4,tasks,reports});
const report=(date='2026-10-30',shift='Night',at=100)=>({...C.freshReport(date,shift,at),hse:'--LT511 STD taken BIS',plant1:'--Plant load 105% --P114 in service',plant2:'--P3404: 3-4 amps delta',lab:'--+4 product reported on higher side'});

test('v1-v3 task backups gain an empty report list without changing task data',()=>{
  for(const version of [2,3]){const t=C.freshTask({id:'task',text:'Keep this task',notes:'Original notes'});const s=C.normalizeState({schemaVersion:version,tasks:[t]});assert.equal(s.tasks[0].notes,'Original notes');assert.deepEqual(s.reports,[]);assert.equal(s.schemaVersion,4);}
  assert.deepEqual(C.normalizeState([]).reports,[]);
});
test('report validation rejects impossible dates, duplicate shifts, and damaged fields',()=>{
  const r=report();assert.throws(()=>state([r,r]));assert.throws(()=>state([{...r,date:'2026-02-30',id:'2026-02-30:Night'}]));assert.throws(()=>state([{...r,id:'wrong'}]));assert.throws(()=>state([{...r,plant1:'x'.repeat(6001)}]));assert.throws(()=>state([{...r,ready:'yes'}]));
});
test('night report is labelled by shift start date and ends next morning',()=>{
  const text=C.reportText(report());assert.match(text,/30-Oct-2026 · 22:00 → 31-Oct-2026 · 06:00/);assert.match(text,/Status: Draft/);
});
test('written report keeps all equipment tags, plus signs, and sections without inventing normal status',()=>{
  const r=report(),text=C.reportText(r);for(const label of ['HSE/SCD Highlights','Lab Highlights','Plant Highlights-1','Plant Highlights-2','Plant Highlights-3'])assert(text.includes(label));
  for(const exact of ['LT511 STD taken BIS','+4 product reported on higher side','105%','P114','P3404: 3-4 amps delta'])assert(text.includes(exact));
  assert.match(text,/Plant Highlights-3\nNot entered/);assert(!text.includes('Remained normal'));assert(!text.includes('--Plant'));
});
test('verbal outline uses all sections unless the author supplies a short summary',()=>{
  const r=report();assert(C.reportText(r,'verbal').includes('P3404: 3-4 amps delta'));
  const short=C.reportText({...r,verbalSummary:'Check P3404 at takeover',pending:'Follow up G3428'},'verbal');assert(short.includes('Check P3404 at takeover'));assert(short.includes('Follow up G3428'));assert(!short.includes('Plant load 105%'));
});
test('device merges preserve separate shifts, latest report edits, and deletion records',()=>{
  const old=report(),edited={...old,plant3:'BXC in service',updatedAt:200},morning=report('2026-10-30','Morning',150);
  const a=state([old,morning]),b=state([edited]);const merged=C.mergeStates(a,b);assert.equal(merged.reports.length,2);assert.equal(merged.reports.find(r=>r.shift==='Night').plant3,'BXC in service');assert.deepEqual(merged,C.mergeStates(b,a));
  assert.equal(C.mergeStates(state([edited]),state([{...edited,deleted:true}])).reports[0].deleted,true);
});
test('task reordering and completion preserve report and roster records',()=>{
  const t=C.freshTask({id:'task',text:'Check equipment'}),s=state([report()],[t]);s.roster=[{id:'2026-10-30',date:'2026-10-30',shift:'Night',note:'Actual duty',updatedAt:1,deleted:false}];
  const changed=C.changeStatus(C.reorderTask(s,'task',null,true,null,200),'task','completed',201);assert.deepEqual(changed.reports,s.reports);assert.deepEqual(changed.roster,s.roster);assert.deepEqual(C.normalizeState(JSON.parse(JSON.stringify(changed))).reports,s.reports);
});
test('Excel includes a separate Shift Reports sheet and literal report text',()=>{
  const r={...report(),ready:true,plant3:'=1+1 <equipment>'},bytes=C.makeXlsx(state([r]));const text=new TextDecoder().decode(bytes);assert(text.includes('name="Shift Reports"'));assert(text.includes('worksheets/sheet3.xml'));assert(text.includes('=1+1 &lt;equipment&gt;'));assert(!text.includes('<f>'));assert(text.includes('31-Oct-2026 · 06:00'));
});
