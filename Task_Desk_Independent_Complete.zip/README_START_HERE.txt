MY TASK DESK — COMPLETE INDEPENDENT WEBSITE
Version 1.0 • 30 October 2026

START HERE
1. Extract Task_Desk_Independent_Complete.zip.
2. For immediate offline use, open My_Task_Desk_Offline.html.
3. For a website, upload the CONTENTS of website/ to your static host.
   index.html must be at the site's root. Cloudflare_Upload.zip contains
   exactly those website files, with index.html at its root.
4. For laptop + phone synchronization, follow SETUP_SYNC.md first.
   Then upload your edited website/config.js with all website files.
5. Open the SAME hosted URL and sign in with the SAME email account
   on each device. A downloaded HTML file keeps a separate local list.

WHAT IS INCLUDED
• Separate HTML, CSS and JavaScript source files; no build step or CDN.
• Tasks: add, edit, finish, delete, restore and undo; search and filters.
• Numbered priorities: drag up/down; drag sideways on the status Board.
  Keyboard arrow controls and an exact-position move button also work.
• Due dates and reminders while the page is open, in Pakistan time.
• Categories, repeating tasks, subtasks, comments and task history.
• Attachments, calendar, editable shift roster and handover.
• Shift end reports: HSE/SCD, Lab, Plant Highlights 1–3, pending work,
  and optional verbal notes. Save drafts, mark ready, reopen, copy,
  print/PDF and export text. Empty sections remain unentered.
• Dark mode, colour themes, larger text and compact spacing.
• JSON, Excel, attachment archives, local copies and optional cloud copies.
• Supabase SQL setup for private account data, backups and attachments.
• Offline application shell and installable website manifest.
• Automated tests and the packaging script.

IMPORTANT PRACTICAL DETAILS
• This package contains CODE, not your existing online tasks. Transfer
  those with Backup & export. See MIGRATE_EXISTING_DATA.md.
• Cloud settings are blank. Offline use works immediately; online sync
  starts after you create your project, run the SQL and sign in.
• The interface may be publicly visible on your host. Each signed-in
  user's cloud records and attachments are restricted by database rules.
  Tasks are also stored in the browser: use a trusted device/browser.
• Reminders require the app/page to be open. Closed-page push, email,
  SMS and scheduled server reminders are NOT configured in this version.
  Existing scheduled reminders for your previous website do not migrate.
• No ChatGPT service, login, token or subscription is used by this app.
  Optional sync uses YOUR Supabase project. Hosting/provider accounts
  and any provider quotas are managed separately by you.
• Export backups periodically. Browser-only data can be lost if browser
  storage is cleared. Keep attachment archives as well as JSON backups.

FOLDERS
website/                 Files to upload (HTML, CSS, JS and assets)
supabase/setup.sql       Run once in your new Supabase project's SQL editor
SETUP_SYNC.md            Connection and account setup, with sync test
MIGRATE_EXISTING_DATA.md Transfer tasks/reports/attachments from the old site
tests/                   Node automated tests (npm test)
tools/package.py         Regenerate the offline HTML and ZIP packages
VALIDATION.md            What was checked and what still needs your project

No package installation is needed to use the website. Development tests
use Node.js; packaging uses Python 3, both with standard libraries only.
