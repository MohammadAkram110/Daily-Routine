# Connect your laptop and phone

The website works immediately in device-only mode. To share the same tasks,
shift reports, roster and attachments across devices, connect your own
Supabase project. You can use the same static website on Cloudflare Pages
or another HTTPS static host. No ChatGPT services are required.

## 1. Prepare the database

1. Create a new Supabase project in your own account. Record your database
   password privately; it never belongs in the website files.
2. Open the project's SQL editor, create a query and paste the complete
   contents of `supabase/setup.sql`. Run the query. It creates three tables,
   two save/backup functions and one private attachments bucket with
   per-user access rules. The script can be run again in that new project.
3. In Authentication → Users, add your own email user with a password you
   choose. If creating the user through an admin form, use its confirmed
   email option, or complete the provider's confirmation flow. This app
   signs in existing users; account creation and password resets are
   managed in your Supabase dashboard. Do not paste a real password in code.
4. Find your project's URL and **publishable** key (or legacy **anon public**
   key) in its connection/API settings. Never use a secret or service-role
   key. Leave all row-level-security rules enabled.

## 2. Connect the website

Edit `website/config.js` in a text editor:

```js
window.TASK_DESK_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT_REF.supabase.co",
  supabaseKey: "YOUR_PUBLISHABLE_OR_ANON_PUBLIC_KEY"
};
```

Use the standard `https://<project-ref>.supabase.co` URL without a path.
These two settings are intended to be public in browser code. Your password,
database password and server secret keys must stay private.

Alternatively, on the hosted website choose **Connect sync**, enter the URL
and public key, and select **Download config.js**. Replace the uploaded
config.js with that file. **Use this project** only saves the connection in
that browser; uploading config.js provides the same connection to every device.

## 3. Upload

Upload the contents of `website/`, including subfolders. Your host's root must
contain `index.html`, `config.js`, the CSS and JS files, plus `downloads/`.
Do not upload the outer complete package as if it were the website. The
included `Cloudflare_Upload.zip` contains the correct website root layout;
regenerate it after changing config.js, or upload the edited website folder.

No npm install or build command is needed. If your host requires an output
folder, choose `website`. This is a static website, not a server-side Worker.
Use HTTPS for service workers, installation and browser notifications.

Your database is separate from your host. Uploading HTML alone does not create
a shared database. A file opened by double-click remains device-only.

## 4. Verify real synchronization

1. Open your hosted URL on the laptop, choose **Sign in** and use your user.
2. Confirm the page displays **Synced to your account**.
3. Add a temporary task called `Sync check from laptop`.
4. Open the same URL on your phone and sign in with the same email/password.
5. Tap the sync status or wait about 20 seconds while the page is visible.
   Confirm that task appears. Edit it on the phone and confirm the edit on
   the laptop. Test a shift report and an attachment as well.
6. Complete or delete the test task; Deleted tasks lets you restore it.

An offline device keeps changes locally and merges them when online. Different
new tasks survive a merge; for the same task/report the latest saved edit wins.
This is not collaborative character-by-character editing. Keep device clocks
accurate and export a backup before making large edits on multiple devices.
Roster, tasks and reports sync; appearance and notification permission are local.

## Backups and reminders

The app offers local daily copies and manual copies. After cloud sync, the
first changed save of a Pakistan calendar day also retains the preceding
cloud document, with up to 30 recent cloud copies. Attachment bytes live in the
private bucket and are not copied into JSON or database snapshots. Use **Export
attachment archive** in addition to JSON to retain a complete portable copy.

Browser notifications require permission and this app to be open. Mobile
browsers can suspend background tabs. Closed-page push, email, SMS and an
independent scheduled reminder server are not included. The old hosted site's
scheduled checker continues to refer to that old site until separately changed.

## If something does not sync

- Recheck the same website, project URL, email account and internet connection.
- If prompted to run setup.sql, run the full supplied SQL in the correct project.
- Check the project is available and Authentication permits password sign-in.
- A public/publishable key belongs in config.js; a secret key is rejected.
- If you changed the uploaded config but this browser still uses another
  project, open Connect sync → Connect your cloud project and save the correct
  URL and public key here too. A browser's saved connection takes precedence.
- If the host serves old assets, refresh the page. When replacing source files,
  change VERSION in service-worker.js and reopen the app to install the update.
- If sign-in expires while offline, keep your list locally and sign in again
  when the network returns. Do not clear browser storage before exporting.

## Privacy and hosting

The static host can serve the interface publicly. Supabase authentication and
row-level-security restrict cloud rows and objects to their owning user.
This does not encrypt data end-to-end. Browser storage and offline copies can
be read by someone who has access to your browser profile or files. Sign out
on shared devices, and use a private/trusted browser profile for work records.
