(() => {
  'use strict';
  const cloud=window.TaskDeskCloud,T=window.TaskDesk,$=id=>document.getElementById(id);
  const localFile=location.protocol==='file:';
  function status(){
    $('account-open').textContent=cloud.user?'Account':cloud.configured?'Sign in':'Connect sync';
    $('connection-current').textContent=localFile?'This downloaded file saves on this device. Open your hosted website to use cloud sync.':cloud.configError||(cloud.configured?'':'Cloud sync is not connected. You can keep using this browser, or connect your Supabase project.');
    if(cloud.configured&&!localFile)$('connection-current').textContent='Project: '+new URL(cloud.configuration.supabaseUrl).hostname;
    $('account-identity').textContent=cloud.user?'Signed in as '+cloud.user.email:'Sign in with your own email and password.';
    $('account-signout').hidden=!cloud.user;$('login-form').hidden=!!cloud.user||!cloud.configured||localFile;
    $('cloud-project-details').open=!cloud.configured;
    if(cloud.configuration){$('cloud-project-url').value=cloud.configuration.supabaseUrl;$('cloud-project-key').value=cloud.configuration.supabaseKey;}
  }
  function open(){status();$('cloud-error').hidden=true;$('cloud-message').textContent='';$('cloud-dialog').showModal();if(cloud.configured&&!cloud.user)$('cloud-email').focus();}
  $('account-open').addEventListener('click',open);
  $('sign-in').addEventListener('click',event=>{event.preventDefault();open();});
  $('cloud-close').addEventListener('click',()=>$('cloud-dialog').close());
  function error(e){$('cloud-error').textContent=e.message||'The operation could not finish.';$('cloud-error').hidden=false;}
  $('connection-form').addEventListener('submit',event=>{event.preventDefault();try{if(localFile)throw new Error('Configure and upload config.js, then use the hosted website for syncing.');cloud.configure({supabaseUrl:$('cloud-project-url').value,supabaseKey:$('cloud-project-key').value});location.reload();}catch(e){error(e);}});
  $('download-config').addEventListener('click',()=>{try{T.download(cloud.publicConfig({supabaseUrl:$('cloud-project-url').value,supabaseKey:$('cloud-project-key').value}),'config.js','application/javascript');$('cloud-message').textContent='Upload this config.js with your website files so the same project is available on every device.';}catch(e){error(e);}});
  $('login-form').addEventListener('submit',async event=>{event.preventDefault();const button=$('cloud-login');button.disabled=true;$('cloud-error').hidden=true;try{await cloud.signIn($('cloud-email').value,$('cloud-password').value);$('cloud-password').value='';await T.syncNow();if(T.getAccount()){$('cloud-dialog').close();T.notify('Signed in. Your list is connected.');}else{$('cloud-message').textContent='Signed in. Check the sync status; the database setup may still be needed.';status();}}catch(e){$('cloud-password').value='';error(e);}finally{button.disabled=false;}});
  $('account-signout').addEventListener('click',async()=>{try{await cloud.signOut();}catch(e){T.notify('Signed out on this device. The connection was unavailable.');}finally{T.leaveAccount();status();$('cloud-dialog').close();}});
  window.addEventListener('taskdesk:auth',status);
  window.addEventListener('taskdesk:synced',status);
  window.addEventListener('taskdesk:render',()=>{$('background-reminders').checked=false;});
  if('serviceWorker'in navigator&&location.protocol==='https:')navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  status();
})();
