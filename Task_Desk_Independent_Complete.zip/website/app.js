(() => {
  'use strict';
  const C=window.TaskDeskCore, $=id=>document.getElementById(id);
  const KEY='my-task-desk.state.v2', OLD='my-task-desk.tasks.v1', PREF='my-task-desk.preferences.v2';
  let state=C.normalizeState({schemaVersion:4,tasks:[]}),ownerId=null,prefs={layout:'list',fired:{}},blockedStorage=false,storageOk=true;
  let view='all',category='all',query='',layout='list',editorId=null,moveId=null,pendingBackup=null;
  let syncRunning=false,syncAgain=false,syncTimer,onlineAccount=null,cloudState='local',syncError='',lastClock=Date.now(),drag=null;
  let undoAction=null,toastTimer;
  const isFile=location.protocol==='file:'||!window.TaskDeskCloud.configured;
  const cloudFetch=(url,options)=>window.TaskDeskCloud.request(url,options);
  const node=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;};
  const icon=name=>{const s=document.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('aria-hidden','true');const u=document.createElementNS('http://www.w3.org/2000/svg','use');u.setAttribute('href','#i-'+name);s.append(u);return s;};
  const button=(label,name,fn,cls='icon-button')=>{const b=node('button',cls);b.type='button';b.setAttribute('aria-label',label);b.title=label;b.append(icon(name));b.addEventListener('click',fn);return b;};
  const clone=value=>JSON.parse(JSON.stringify(value));
  function stamp(){lastClock=Math.max(Date.now(),lastClock+1,...state.tasks.map(t=>t.updatedAt+1),...(state.roster??[]).map(r=>r.updatedAt+1),...(state.reports??[]).map(r=>r.updatedAt+1),(state.settings?.updatedAt??0)+1);return lastClock;}
  function fingerprint(s){return JSON.stringify({tasks:[...s.tasks].sort((a,b)=>a.id.localeCompare(b.id)),roster:[...(s.roster??[])].sort((a,b)=>a.id.localeCompare(b.id)),reports:[...(s.reports??[])].sort((a,b)=>a.id.localeCompare(b.id)),settings:s.settings??{updatedAt:0,backgroundReminders:true}});}
  function preferences(){try{localStorage.setItem(PREF,JSON.stringify(prefs));}catch{}}
  try{const raw=localStorage.getItem(KEY);if(raw){const saved=JSON.parse(raw);state=C.normalizeState(saved);ownerId=saved.ownerId??null;}else{const old=localStorage.getItem(OLD);if(old)state=C.normalizeState(JSON.parse(old));}}
  catch(error){blockedStorage=true;storageOk=false;}
  try{const p=JSON.parse(localStorage.getItem(PREF)||'{}');if(p&&typeof p==='object'&&!Array.isArray(p))prefs={...prefs,...p};}catch{}if(!prefs.fired||typeof prefs.fired!=='object')prefs.fired={};layout=['list','board'].includes(prefs.layout)?prefs.layout:'list';
  function pendingCount(){if(isFile)return 0;const remote=prefs.remoteVersions?.ownerId===ownerId?prefs.remoteVersions:{};return state.tasks.filter(t=>(remote.tasks?.[t.id]??'')!==t.updatedAt+':'+t.deleted).length+(state.roster??[]).filter(r=>(remote.roster?.[r.id]??'')!==r.updatedAt+':'+r.deleted).length+(state.reports??[]).filter(r=>(remote.reports?.[r.id]??'')!==r.updatedAt+':'+r.deleted).length+((state.settings?.updatedAt??0)>(remote.settings??0)?1:0);}
  function rememberCloud(confirmed){prefs.lastSync=Date.now();prefs.remoteVersions={ownerId,tasks:Object.fromEntries(confirmed.tasks.map(t=>[t.id,t.updatedAt+':'+t.deleted])),roster:Object.fromEntries((confirmed.roster??[]).map(r=>[r.id,r.updatedAt+':'+r.deleted])),reports:Object.fromEntries((confirmed.reports??[]).map(r=>[r.id,r.updatedAt+':'+r.deleted])),settings:confirmed.settings?.updatedAt??0};preferences();}
  function saveLocal(){if(blockedStorage){updateSyncLabel();return;}try{localStorage.setItem(KEY,JSON.stringify({...state,ownerId}));storageOk=true;}catch{storageOk=false;}updateSyncLabel();}
  function updateSyncLabel(){let text=isFile?'Saved on this device':'Saved on this device';if(blockedStorage)text='Saved list could not be read';else if(!storageOk)text='Browser saving unavailable';else if(cloudState==='syncing')text='Syncing your tasks…';else if(cloudState==='auth')text='Sign in to sync';else if(cloudState==='error')text='Saved here · sync needs attention';else if(cloudState==='offline')text='Offline · saved on this device';else if(pendingCount()&&onlineAccount)text='Saved here · '+pendingCount()+' changes waiting';else if(cloudState==='synced')text='Synced to your account';$('save-status').textContent=text;$('sync-button').classList.toggle('warning',!storageOk||['auth','error','offline'].includes(cloudState));$('sync-account').textContent=onlineAccount?onlineAccount.name:isFile?'Device-only mode':'';if($('saving-details'))$('saving-details').textContent=isFile?'Connect sync to use the same list on laptop and mobile.':cloudState==='error'?syncError:cloudState==='auth'?'Sign in with the same email account on desktop and mobile.':(prefs.lastSync?'Last sync '+C.formatDate(prefs.lastSync,true):'Online sync not yet verified')+(pendingCount()?' · '+pendingCount()+' pending':'');}
  function closeToast(){clearTimeout(toastTimer);$('toast').hidden=true;undoAction=null;}
  function notify(message,undo=null){clearTimeout(toastTimer);undoAction=undo;$('toast-message').textContent=message;$('undo-button').hidden=!undo;$('toast').hidden=false;toastTimer=setTimeout(closeToast,10000);}
  function scheduleSync(){if(isFile)return;clearTimeout(syncTimer);syncTimer=setTimeout(syncNow,600);}
  function undoChanges(before,after){const old=new Map(before.tasks.map(t=>[t.id,t]));const changed=new Set(after.tasks.filter(t=>JSON.stringify(old.get(t.id))!==JSON.stringify(t)).map(t=>t.id));const now=stamp();const oldRoster=new Map((before.roster??[]).map(r=>[r.id,r]));const changedRoster=new Set((after.roster??[]).filter(r=>JSON.stringify(oldRoster.get(r.id))!==JSON.stringify(r)).map(r=>r.id));const oldReports=new Map((before.reports??[]).map(r=>[r.id,r]));const changedReports=new Set((after.reports??[]).filter(r=>JSON.stringify(oldReports.get(r.id))!==JSON.stringify(r)).map(r=>r.id));state={...state,schemaVersion:4,reports:(state.reports??[]).map(r=>changedReports.has(r.id)?{...(oldReports.get(r.id)??{...r,deleted:true}),updatedAt:now}:r),tasks:state.tasks.map(t=>changed.has(t.id)?C.log(old.has(t.id)?{...old.get(t.id)}:{...t,deleted:true},'Previous action undone',now):t),roster:(state.roster??[]).map(r=>changedRoster.has(r.id)?{...(oldRoster.get(r.id)??{...r,deleted:true}),updatedAt:now}:r),settings:JSON.stringify(before.settings)!==JSON.stringify(after.settings)?{...before.settings,updatedAt:now}:state.settings};saveLocal();render();scheduleSync();}
  function mutate(fn,message,allowUndo=true){const before=clone(state);const next=fn(state);if(fingerprint(before)===fingerprint(next))return;window.TaskDeskExtras?.beforeChange(before,message);state=next;saveLocal();render();scheduleSync();if(message)notify(message,allowUndo?()=>undoChanges(before,next):null);}
  $('toast-close').addEventListener('click',closeToast);
  $('undo-button').addEventListener('click',()=>{const action=undoAction;closeToast();if(action){action();notify('Previous action undone.');}});
  $('toast').addEventListener('mouseenter',()=>clearTimeout(toastTimer));$('toast').addEventListener('focusin',()=>clearTimeout(toastTimer));
  for(const event of ['mouseleave','focusout'])$('toast').addEventListener(event,()=>{toastTimer=setTimeout(closeToast,10000);});

  async function syncNow(){
    if(isFile||blockedStorage)return;
    if(syncRunning){syncAgain=true;return;}
    if(!navigator.onLine){cloudState='offline';updateSyncLabel();return;}
    const startedUser=window.TaskDeskCloud.user?.id??null;const beforeSync=fingerprint(state);syncRunning=true;syncAgain=false;cloudState='syncing';updateSyncLabel();
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),12000);
    try{
      const response=await cloudFetch('/api/state',{cache:'no-store',signal:controller.signal});
      if(startedUser!==(window.TaskDeskCloud.user?.id??null))return;
      if(response.status===401){cloudState='auth';onlineAccount=null;$('sign-in').hidden=location.hostname==='terminal.local';return;}
      if(!response.ok){let details;try{details=await response.json();}catch{}throw new Error(details?.error||(response.status>=500?'The sync server is unavailable. Your tasks stay on this device; click Sync to retry.':'Your online list could not be read. Your tasks stay on this device; click Sync to retry.'));}
      if(!response.headers.get('content-type')?.includes('application/json'))throw new Error('Sync returned an unexpected response. Your tasks stay on this device; click Sync to retry.');
      const data=await response.json();const remote=C.normalizeState(data.document);
      if(!data.user?.id)throw new Error('Sign in to sync your tasks.');
      if(ownerId!==data.user.id){if(ownerId)localStorage.setItem(KEY+'.'+ownerId,JSON.stringify({...state,ownerId}));const cached=localStorage.getItem(KEY+'.'+data.user.id),target=cached?C.normalizeState(JSON.parse(cached)):C.normalizeState({schemaVersion:4,tasks:[]});state=ownerId?target:C.mergeStates(state,target);}
      ownerId=data.user.id;onlineAccount=data.user;$('sign-in').hidden=true;
      state=C.mergeStates(state,remote);let confirmed=remote;saveLocal();
      if(fingerprint(state)!==fingerprint(remote)){
        const pushed=await cloudFetch('/api/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(state),signal:controller.signal});
        if(startedUser!==(window.TaskDeskCloud.user?.id??null))return;
        if(pushed.status===401){cloudState='auth';onlineAccount=null;$('sign-in').hidden=location.hostname==='terminal.local';return;}
        if(!pushed.headers.get('content-type')?.includes('application/json'))throw new Error('The sync server could not save your list. Your tasks stay on this device; click Sync to retry.');
        const saved=await pushed.json();if(!pushed.ok)throw new Error(saved.error||'Sync could not finish.');
        const server=C.normalizeState(saved.document);confirmed=server;prefs.backupWarning=!!saved.backupWarning;state=C.mergeStates(state,server);saveLocal();
        if(fingerprint(state)!==fingerprint(server))syncAgain=true;
      }
      cloudState='synced';syncError='';rememberCloud(confirmed);$('sync-button').title='Sync now';if(!drag&&beforeSync!==fingerprint(state))render();window.dispatchEvent(new Event('taskdesk:synced'));
    }catch(error){cloudState=navigator.onLine?'error':'offline';syncError=error.name==='AbortError'?'Sync timed out. Your tasks stay on this device; click Sync to retry.':error.message||'Sync is paused. Your changes stay on this device.';$('sync-button').title=syncError;}
    finally{clearTimeout(timeout);syncRunning=false;updateSyncLabel();if(syncAgain){syncAgain=false;scheduleSync();}}
  }
  $('sync-button').addEventListener('click',()=>{if(isFile)notify('This list is saved on this device. Use Connect sync to configure your cloud account.');else syncNow();});
  window.addEventListener('online',syncNow);window.addEventListener('offline',()=>{cloudState='offline';updateSyncLabel();});
  setInterval(()=>{if(document.visibilityState==='visible'&&!drag)syncNow();},20000);
  window.addEventListener('storage',event=>{if(event.key!==KEY||!event.newValue)return;try{const other=JSON.parse(event.newValue);if((other.ownerId??null)!==ownerId)return;const merged=C.mergeStates(state,C.normalizeState(other));if(fingerprint(state)!==fingerprint(merged)){state=merged;render();scheduleSync();}}catch{}});

  function fillSelect(el,values,first){el.replaceChildren();const option=node('option','',first);option.value='';el.append(option);for(const v of values.filter(Boolean)){const o=node('option','',v);o.value=v;el.append(o);}}
  fillSelect($('edit-area'),C.AREAS,'Choose an area');fillSelect($('edit-shift'),C.SHIFTS,'No shift');
  fillSelect($('filter-area'),C.AREAS,'All areas');$('filter-area').options[0].value='all';
  fillSelect($('filter-shift'),C.SHIFTS,'All shifts');$('filter-shift').options[0].value='all';
  const done=t=>t.status==='completed';
  const overdue=t=>!done(t)&&t.dueAt!==null&&t.dueAt<Date.now();
  function inView(t,name){if(name==='trash')return t.deleted;if(t.deleted)return false;if(name==='completed')return done(t);if(name==='overdue')return overdue(t);if(name==='today')return !done(t)&&(t.dutyDate===C.dateInput(Date.now())||t.dueAt!==null&&C.dateInput(t.dueAt)===C.dateInput(Date.now()));if(name==='upcoming')return !done(t)&&t.dueAt!==null&&C.dateInput(t.dueAt)>C.dateInput(Date.now());return true;}
  function matches(t){return(category==='all'||t.category===category)&&['priority','status','area','shift'].every(k=>{const v=$('filter-'+k).value;return v==='all'||t[k]===v;})&&(!query||[t.text,...C.fields.map(f=>t[f])].join(' ').toLocaleLowerCase().includes(query));}
  function visibleTasks(){const tasks=view==='trash'?state.tasks.filter(t=>t.deleted).sort((a,b)=>b.updatedAt-a.updatedAt):C.active(state.tasks);return tasks.filter(t=>inView(t,view)&&matches(t));}
  function setView(next){view=next;document.querySelectorAll('[data-view]').forEach(b=>{const selected=b.dataset.view===view;b.classList.toggle('active',selected);if(selected)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});render();}
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
  $('brand').addEventListener('click',event=>{event.preventDefault();resetFilters();setView('all');$('task-input').focus();});
  document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.category;document.querySelectorAll('[data-category]').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',String(x===b));});render();}));
  $('search-input').addEventListener('input',e=>{query=e.target.value.trim().toLocaleLowerCase();render();});
  for(const name of ['priority','status','area','shift'])$('filter-'+name).addEventListener('change',render);
  $('filter-toggle').addEventListener('click',()=>{const hidden=$('extra-filters').hidden;$('extra-filters').hidden=!hidden;$('filter-toggle').setAttribute('aria-expanded',String(hidden));});
  function resetFilters(){category='all';query='';$('search-input').value='';for(const f of ['priority','status','area','shift'])$('filter-'+f).value='all';document.querySelectorAll('[data-category]').forEach(b=>{b.classList.toggle('selected',b.dataset.category==='all');b.setAttribute('aria-pressed',String(b.dataset.category==='all'));});render();}
  $('reset-filters').addEventListener('click',resetFilters);$('empty-reset').addEventListener('click',resetFilters);
  for(const type of ['list','board'])$(type+'-view').addEventListener('click',()=>{layout=type;prefs.layout=type;preferences();render();});
  $('empty-add').addEventListener('click',()=>{$('task-input').focus();$('task-input').scrollIntoView({block:'center',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});});

  function changeStatus(id,status){const task=state.tasks.find(t=>t.id===id);const repeat=task?.repeat&&status==='completed'&&!done(task);mutate(s=>C.changeStatus(s,id,status,stamp()),repeat?'Completed. The next recurring task is ready.':status==='completed'?'Task completed. Add a closing comment in task details.':'Moved to '+C.labels[status]+'.');}
  function deleteTask(id){const now=stamp();mutate(s=>({...s,tasks:s.tasks.map(t=>t.id===id?C.log({...t,deleted:true},'Deleted',now):t)}),'Task moved to Deleted tasks.');}
  function restoreTask(id){const now=stamp();mutate(s=>({...s,tasks:s.tasks.map(t=>t.id===id?C.log({...t,deleted:false},'Restored',now):t)}),'Task restored.');}
  $('clear-completed').addEventListener('click',()=>{const completed=visibleTasks().filter(done);if(!completed.length)return;const now=stamp();mutate(s=>({...s,tasks:s.tasks.map(t=>completed.some(x=>x.id===t.id)?C.log({...t,deleted:true},'Completed task cleared',now):t)}),completed.length+' completed task'+(completed.length===1?'':'s')+' moved to Deleted tasks.');});
  function tag(text,type,name){const s=node('span','tag '+(type||''),undefined);if(name)s.append(icon(name));s.append(document.createTextNode(text));return s;}
  function focusGrip(id){requestAnimationFrame(()=>{const row=[...$('tasks-container').querySelectorAll('.task-card')].find(r=>r.dataset.id===id);row?.querySelector('.grip')?.focus();});}
  function makeCard(t,rank,trash=false){
    const card=node('article','task-card'+(overdue(t)?' overdue-task':'')+(done(t)?' is-complete':'')+(t.priority==='critical'?' critical':'')+(trash?' trash-card':''));card.dataset.id=t.id;
    if(trash){const content=node('div','card-content');content.append(node('span','task-title',t.text),node('div','task-meta','Deleted '+C.formatDate(t.updatedAt,true)));card.append(content,button('Restore task: '+t.text,'sync',()=>restoreTask(t.id)));return card;}
    const leading=node('div','rank-grip');leading.append(node('span','rank','#'+rank));const grip=button('Drag task: '+t.text,'grip',()=>{},'grip');grip.setAttribute('aria-describedby','drag-instructions');grip.title='Drag to reorder. Keyboard: ↑ ↓ order, ← → status.';grip.addEventListener('pointerdown',event=>beginDrag(event,t.id,card,grip));grip.addEventListener('keydown',event=>gripKey(event,t.id));leading.append(grip);
    const check=node('input','task-check');check.type='checkbox';check.checked=done(t);check.setAttribute('aria-label',(done(t)?'Reopen task: ':'Complete task: ')+t.text);check.addEventListener('change',()=>changeStatus(t.id,check.checked?'completed':'pending'));
    const content=node('div','card-content'),title=node('button','task-title',t.text);title.type='button';title.title='Open task details';title.addEventListener('click',()=>openEditor(t.id));content.append(title);
    const tags=node('div','task-tags');tags.append(tag(t.priority[0].toUpperCase()+t.priority.slice(1),'priority-'+t.priority),tag(t.category,t.category==='Personal'?'personal':''));
    if(t.dutyDate)tags.append(tag('Duty '+C.formatDate(C.fromInputs(t.dutyDate,'00:00'))));if(t.dueAt!==null){const text=done(t)?C.formatDate(t.dueAt,true):overdue(t)?'Overdue · '+C.formatDate(t.dueAt,true):C.dateInput(t.dueAt)===C.dateInput(Date.now())?'Today · '+C.timeInput(t.dueAt):C.formatDate(t.dueAt,true);tags.append(tag(text,overdue(t)?'overdue':'due','calendar'));}
    if(t.repeat)tags.append(tag('Every '+t.repeat.every+' '+t.repeat.unit+(t.repeat.every===1?'':'s'),'','repeat'));
    if(t.area)tags.append(tag(t.area));if(t.mwrStatus==='to-raise')tags.append(tag('MWR to raise','priority-high'));if(t.equipment)tags.append(tag(t.equipment));if(t.handover){const h=tag('Handover','handover-tag');h.title=t.handover;tags.append(h);}content.append(tags);
    const details=[t.responsible?'For '+t.responsible:t.assignedBy?'From '+t.assignedBy:'',t.shift? t.shift+' shift':'',t.mwr?'MWR '+t.mwr:'',done(t)&&t.completedAt?'Done '+C.formatDate(t.completedAt,true):''].filter(Boolean);
    if(details.length)content.append(node('div','task-meta',details.join(' · ')));
    const tools=node('div','row-tools'),status=node('select','status-select');status.setAttribute('aria-label','Status for '+t.text);for(const s of C.STATUSES){const o=node('option','',C.labels[s]);o.value=s;o.selected=s===t.status;status.append(o);}status.addEventListener('change',()=>changeStatus(t.id,status.value));tools.append(status,button('Move task: '+t.text,'move',()=>openMove(t.id)),button('Edit task: '+t.text,'edit',()=>openEditor(t.id)),button('Delete task: '+t.text,'trash',()=>deleteTask(t.id),'icon-button delete-button'));
    card.append(leading,check,content,tools);window.TaskDeskExtras?.decorateCard(card,t);return card;
  }
  function render(){
    const all=C.active(state.tasks),completed=all.filter(done).length,pending=all.length-completed,percent=all.length?Math.round(completed/all.length*100):0;
    $('today-date').textContent=C.formatDate(Date.now());
    for(const name of ['all','today','upcoming','overdue','completed'])$('nav-'+name).textContent=all.filter(t=>inView(t,name)).length;
    $('trash-count').textContent=state.tasks.filter(t=>t.deleted).length;$('pending-total').textContent=pending;$('completed-total').textContent=completed;$('overdue-total').textContent=all.filter(overdue).length;
    $('progress-label').textContent=percent+'%';$('progress-fill').style.width=percent+'%';$('progress-track').setAttribute('aria-valuenow',percent);
    document.body.classList.toggle('report-view',view==='reports');const special=['calendar','roster','handover','reports'].includes(view);$('tasks-section').hidden=special;$('workspace-panel').hidden=!special;if(special){window.TaskDeskExtras?.renderWorkspace(view);updateReminders();window.dispatchEvent(new Event('taskdesk:render'));return;}
    const oldRects=new Map([...$('tasks-container').querySelectorAll('.task-card')].map(el=>[el.dataset.id,el.getBoundingClientRect()]));
    const shown=visibleTasks();$('visible-count').textContent=shown.length;$('list-title').textContent={all:'All tasks',today:'Today',upcoming:'Upcoming tasks',overdue:'Overdue tasks',completed:'Completed tasks',trash:'Deleted tasks'}[view];
    const effectiveLayout=view==='trash'?'list':layout;$('list-view').setAttribute('aria-pressed',String(effectiveLayout==='list'));$('board-view').setAttribute('aria-pressed',String(effectiveLayout==='board'));$('board-view').disabled=view==='trash';
    const count=['priority','status','area','shift'].filter(f=>$('filter-'+f).value!=='all').length;$('filter-count').textContent=count?'('+count+')':'';
    $('clear-completed').disabled=!shown.some(done);$('clear-completed').hidden=view==='trash';$('drag-instructions').textContent=view==='trash'?'Deleted tasks stay here until you restore them.':'Drag the grip to arrange your order. Use Board to move sideways between statuses.';
    const ranks=new Map(all.map((t,i)=>[t.id,i+1])),container=$('tasks-container');container.replaceChildren();container.hidden=!shown.length;
    if(effectiveLayout==='board'){
      const board=node('div','task-board');
      for(const status of C.STATUSES){const col=node('section','board-column');col.dataset.status=status;col.setAttribute('aria-label',C.labels[status]+' column');const head=node('div','board-header');head.append(node('span','board-dot'),node('span','',C.labels[status]),node('span','counter',shown.filter(t=>t.status===status).length));const drop=node('div','board-drop');for(const t of shown.filter(t=>t.status===status))drop.append(makeCard(t,ranks.get(t.id)));if(!drop.children.length)drop.append(node('div','board-empty','Drag a task here'));col.append(head,drop);board.append(col);}container.append(board);
    }else{const list=node('div','task-list');for(const t of shown)list.append(makeCard(t,ranks.get(t.id),view==='trash'));container.append(list);}
    $('empty-state').hidden=shown.length>0;const hasFilter=query||category!=='all'||count>0;
    let title='A clear desk. A fresh start.',message='Add your first task above. Put the most important one at the top.';
    if(hasFilter){title='No matching tasks.';message='Try another search, or clear your filters.';}
    else if(view==='trash'){title='Nothing in Deleted tasks.';message='Deleted tasks stay recoverable here.';}
    else if(view==='completed'){title='Your wins will live here.';message='Complete a task to record its date and history.';}
    else if(view==='overdue'){title='Nothing overdue.';message='A little breathing room. Keep it going.';}
    else if(view==='today'){title='A little room in today.';message='No pending tasks are due today. You can add one above.';}
    else if(view==='upcoming'){title='Nothing scheduled ahead.';message='Add a due date to a task and see it here.';}
    $('empty-title').textContent=title;$('empty-message').textContent=message;$('empty-add').hidden=hasFilter||['trash','completed','overdue'].includes(view);$('empty-reset').hidden=!hasFilter;$('empty-add').firstChild.textContent=all.length?'Add another task ':'Add your first task ';
    $('task-summary').textContent=all.length?pending+' still to do · '+completed+' completed · '+shown.length+' shown':'Your list is ready when you are.';
    updateReminders();window.dispatchEvent(new Event('taskdesk:render'));if(!matchMedia('(prefers-reduced-motion: reduce)').matches)for(const el of $('tasks-container').querySelectorAll('.task-card')){const old=oldRects.get(el.dataset.id),now=el.getBoundingClientRect();if(old&&(Math.abs(old.x-now.x)>1||Math.abs(old.y-now.y)>1))el.animate([{transform:'translate('+ (old.x-now.x)+'px,'+(old.y-now.y)+'px)'},{transform:'none'}],{duration:180,easing:'ease-out'});}
  }

  function quickData(){return{text:$('task-input').value.trim(),dueAt:C.fromInputs($('quick-date').value,$('quick-time').value),priority:$('quick-priority').value,category:$('quick-category').value};}
  $('task-input').addEventListener('input',()=>$('task-input').setCustomValidity(''));
  $('task-form').addEventListener('submit',event=>{event.preventDefault();const data=quickData();if(!data.text){$('task-input').setCustomValidity('Please write a task.');$('task-input').reportValidity();return;}const now=stamp();const t=C.freshTask({...data,history:[{at:now,action:'Task created',note:''}]},now,Math.max(-1,...C.active(state.tasks).map(t=>t.order))+1);mutate(s=>({...s,tasks:[...s.tasks,t]}),'Task added.',false);$('task-input').value='';$('quick-date').value='';$('quick-time').value='';if(!inView(t,view)||!matches(t)){resetFilters();setView('all');}$('task-input').focus();});
  $('new-details').addEventListener('click',()=>openEditor(null,quickData()));
  const form=$('editor-form'),field=name=>form.elements.namedItem(name);
  function repeatControls(){const preset=field('repeatPreset').value,enabled=preset!=='none';$('repeat-options').hidden=!enabled;$('repeat-every-field').hidden=preset!=='custom';$('repeat-unit-field').hidden=preset!=='custom';field('repeatEvery').required=preset==='custom';field('dueDate').required=enabled&&field('repeatFrom').value==='schedule';}
  $('repeat-preset').addEventListener('change',repeatControls);field('repeatFrom').addEventListener('change',repeatControls);
  function openEditor(id,data={}){
    editorId=id;form.reset();const t=id?state.tasks.find(t=>t.id===id):C.freshTask(data);if(!t)return;
    $('task-dialog-title').textContent=id?'Task details':'A little more detail';field('text').value=t.text;for(const f of ['priority','category','status','reminderMinutes',...C.fields])field(f).value=String(t[f]??'');field('dueDate').value=C.dateInput(t.dueAt);field('dueTime').value=C.timeInput(t.dueAt);
    let preset='none';if(t.repeat){const {every,unit,from}=t.repeat;preset=every===1?({day:'daily',week:'weekly',month:'monthly',year:'yearly'}[unit]):every===3&&unit==='month'?'quarterly':'custom';field('repeatEvery').value=every;field('repeatUnit').value=unit;field('repeatFrom').value=from;}field('repeatPreset').value=preset;repeatControls();
    $('plant-details').open=!!id&&C.fields.some(f=>f!=='closingComment'&&t[f]);$('completion-details').open=false;$('editor-error').hidden=true;
    $('editor-created').textContent=id?'Created '+C.formatDate(t.createdAt,true)+(t.completedAt?' · Completed '+C.formatDate(t.completedAt,true):''):'';
    const history=$('task-history');history.replaceChildren();if(!t.history.length)history.append(node('p','muted','Your task history will appear here.'));for(const h of [...t.history].reverse()){const item=node('div','history-item',h.action);item.append(node('small','',C.formatDate(h.at,true)));if(h.note)item.append(node('p','',h.note));history.append(item);}
    window.TaskDeskExtras?.openEditor(t);$('task-dialog').showModal();$('edit-text').focus();
  }
  form.addEventListener('submit',event=>{event.preventDefault();try{
    const original=editorId?state.tasks.find(t=>t.id===editorId):null,now=stamp();const data={text:field('text').value.trim(),priority:field('priority').value,category:field('category').value,dueAt:C.fromInputs(field('dueDate').value,field('dueTime').value),reminderMinutes:Number(field('reminderMinutes').value)};
    for(const f of C.fields)data[f]=field(f).value.trim();Object.assign(data,window.TaskDeskExtras?.readTaskFields()??{});
    const presets={daily:[1,'day'],weekly:[1,'week'],monthly:[1,'month'],quarterly:[3,'month'],yearly:[1,'year']},preset=field('repeatPreset').value;
    if(preset!=='none'){const [every,unit]=preset==='custom'?[Number(field('repeatEvery').value),field('repeatUnit').value]:presets[preset];const keepAnchor=original?.repeat&&original.dueAt===data.dueAt;data.repeat={every,unit,from:field('repeatFrom').value,anchorDay:keepAnchor?original.repeat.anchorDay:Number(C.dateInput(data.dueAt??now).slice(-2))};}else data.repeat=null;
    let t=original?C.log({...original,...data},data.closingComment!==original.closingComment&&done(original)?'Closing comment updated':'Details updated',now,data.closingComment!==original.closingComment?data.closingComment:''):C.freshTask({...data,history:[{at:now,action:'Task created',note:''}]},now,Math.max(-1,...C.active(state.tasks).map(t=>t.order))+1);
    t=C.validateTask(t);const status=field('status').value;mutate(s=>C.changeStatus({...s,tasks:original?s.tasks.map(item=>item.id===t.id?t:item):[...s.tasks,t]},t.id,status,now+1),original?'Task updated.':'Task added.');$('task-dialog').close();if(!original){$('task-input').value='';$('quick-date').value='';$('quick-time').value='';if(!inView(t,view)||!matches(t)){resetFilters();setView('all');}}
  }catch(error){$('editor-error').textContent=error.message;$('editor-error').hidden=false;}});
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
  document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}));

  function openMove(id){const t=state.tasks.find(t=>t.id===id),ordered=C.active(state.tasks);if(!t)return;moveId=id;$('move-task-name').textContent=t.text;$('move-position').max=ordered.length;$('move-position').value=ordered.findIndex(t=>t.id===id)+1;$('move-status').value=t.status;$('move-dialog').showModal();$('move-position').focus();$('move-position').select();}
  $('move-form').addEventListener('submit',event=>{event.preventDefault();const position=Number($('move-position').value),status=$('move-status').value,now=stamp();const others=C.active(state.tasks).filter(t=>t.id!==moveId);const target=others[position-1]?.id??null;mutate(s=>C.reorderTask(C.changeStatus(s,moveId,status,now),moveId,target,false,null,now+1),'Task moved to position '+position+'.');$('move-dialog').close();focusGrip(moveId);});
  function gripKey(event,id){if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();const tasks=C.active(state.tasks),i=tasks.findIndex(t=>t.id===id),t=tasks[i];if(event.key==='ArrowUp'&&i>0)mutate(s=>C.reorderTask(s,id,tasks[i-1].id,false,null,stamp()),'Task moved up.');else if(event.key==='ArrowDown'&&i<tasks.length-1)mutate(s=>C.reorderTask(s,id,tasks[i+1].id,true,null,stamp()),'Task moved down.');else if(event.key==='ArrowLeft'||event.key==='ArrowRight'){const j=C.STATUSES.indexOf(t.status)+(event.key==='ArrowRight'?1:-1);if(C.STATUSES[j])changeStatus(id,C.STATUSES[j]);}focusGrip(id);}
  function clearDropMarks(){document.querySelectorAll('.drop-before,.drop-after,.drop-target').forEach(el=>el.classList.remove('drop-before','drop-after','drop-target'));}
  function dragTarget(){if(!drag?.ghost)return;clearDropMarks();const el=document.elementFromPoint(drag.x,drag.y);const card=el?.closest('.task-card'),column=el?.closest('.board-column'),container=el?.closest('#tasks-container');drag.target=null;if(!container||card?.dataset.id===drag.id)return;if(card&&card.dataset.id!==drag.id&&!card.classList.contains('drag-ghost')){const r=card.getBoundingClientRect(),after=drag.y>r.top+r.height/2;card.classList.add(after?'drop-after':'drop-before');drag.target={id:card.dataset.id,after,status:column?.dataset.status??null};}else if(column){column.classList.add('drop-target');drag.target={id:null,after:true,status:column.dataset.status};}else if(!card){const rows=[...container.querySelectorAll('.task-card')].filter(r=>r.dataset.id!==drag.id);if(rows.length){const last=rows[rows.length-1];const after=drag.y>last.getBoundingClientRect().top;const target=after?last:rows[0];target.classList.add(after?'drop-after':'drop-before');drag.target={id:target.dataset.id,after,status:null};}}}
  function scrollDrag(){if(!drag?.ghost)return;const edge=65;let dy=drag.y<edge?-12:drag.y>innerHeight-edge?12:0;if(dy)window.scrollBy(0,dy);const board=$('tasks-container').querySelector('.task-board');if(board){const r=board.getBoundingClientRect();if(drag.x<r.left+45)board.scrollLeft-=12;else if(drag.x>r.right-45)board.scrollLeft+=12;}dragTarget();drag.frame=requestAnimationFrame(scrollDrag);}
  function beginDrag(event,id,card,grip){if(event.button!==0||drag)return;event.preventDefault();grip.focus();drag={id,card,grip,pointer:event.pointerId,startX:event.clientX,startY:event.clientY,x:event.clientX,y:event.clientY,ghost:null,target:null};grip.setPointerCapture(event.pointerId);
    const move=event=>{if(!drag)return;drag.x=event.clientX;drag.y=event.clientY;if(!drag.ghost&&Math.hypot(drag.x-drag.startX,drag.y-drag.startY)>5){const rect=card.getBoundingClientRect();drag.ghost=card.cloneNode(true);drag.ghost.classList.add('drag-ghost');drag.ghost.classList.toggle('board-card-ghost',!!card.closest('.task-board'));drag.ghost.setAttribute('aria-hidden','true');drag.ghost.style.width=rect.width+'px';drag.dx=drag.startX-rect.left;drag.dy=drag.startY-rect.top;document.body.append(drag.ghost);card.classList.add('is-dragging');document.body.classList.add('dragging-active');drag.frame=requestAnimationFrame(scrollDrag);}if(drag.ghost){drag.ghost.style.left=drag.x-drag.dx+'px';drag.ghost.style.top=drag.y-drag.dy+'px';dragTarget();}};
    const end=event=>{const current=drag;if(!current)return;const target=current.target;const didDrag=!!current.ghost;cleanupDrag();if(event.type!=='pointercancel'&&didDrag&&target){const now=stamp();mutate(s=>C.reorderTask(s,id,target.id,target.after,target.status,now),'Task order updated'+(target.status?' · '+C.labels[target.status]:'')+'.');const rank=C.active(state.tasks).findIndex(t=>t.id===id)+1;$('announcer').textContent='Task moved to position '+rank+'.';focusGrip(id);}grip.removeEventListener('pointermove',move);grip.removeEventListener('pointerup',end);grip.removeEventListener('pointercancel',end);};
    drag.cancel=()=>end({type:'pointercancel'});grip.addEventListener('pointermove',move);grip.addEventListener('pointerup',end);grip.addEventListener('pointercancel',end);
  }
  function cleanupDrag(){if(!drag)return;cancelAnimationFrame(drag.frame);drag.ghost?.remove();drag.card.classList.remove('is-dragging');document.body.classList.remove('dragging-active');clearDropMarks();try{drag.grip.releasePointerCapture(drag.pointer);}catch{}drag=null;}
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&drag){event.preventDefault();drag.cancel();}});

  function download(data,name,type){const url=URL.createObjectURL(new Blob([data],{type})),a=node('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  $('backup-open').addEventListener('click',()=>{$('restore-error').hidden=true;$('backup-dialog').showModal();});
  $('backup-download').addEventListener('click',()=>download(JSON.stringify({...state,exportedAt:new Date().toISOString(),timezone:'Asia/Karachi'},null,2),'Task_Desk_Backup_'+C.dateInput(Date.now())+'.json','application/json'));
  $('excel-download').addEventListener('click',()=>download(C.makeXlsx(state),'Task_Desk_'+C.dateInput(Date.now())+'.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'));
  $('print-tasks').addEventListener('click',()=>{$('backup-dialog').close();window.print();});
  $('restore-file').addEventListener('change',async event=>{pendingBackup=null;$('restore-error').hidden=true;$('restore-options').hidden=true;const file=event.target.files[0];if(!file)return;try{if(file.size>8_000_000)throw new Error('Choose a backup smaller than 8 MB.');pendingBackup=C.normalizeState(JSON.parse(await file.text()));$('restore-summary').textContent=C.active(pendingBackup.tasks).length+' active tasks and '+pendingBackup.reports.filter(r=>!r.deleted).length+' shift reports found. Merge keeps your other tasks; backup versions replace matching task IDs.';$('restore-options').hidden=false;}catch(error){$('restore-error').textContent=error.message||'This backup could not be read.';$('restore-error').hidden=false;}});
  $('restore-confirm').addEventListener('click',()=>{if(!pendingBackup)return;blockedStorage=false;window.TaskDeskExtras.restoreDocument(pendingBackup,$('restore-method').value==='replace');$('backup-dialog').close();pendingBackup=null;$('restore-file').value='';$('restore-options').hidden=true;resetFilters();setView('all');});

  function dueReminders(){return C.active(state.tasks).filter(t=>!done(t)&&t.dueAt!==null&&t.reminderMinutes>=0&&Date.now()>=t.dueAt-t.reminderMinutes*60000);}
  function updateReminders(){const tasks=dueReminders();$('reminder-count').textContent=tasks.length;$('reminder-count').hidden=!tasks.length;}
  function reminderSettings(){const available='Notification'in window;const permission=available?Notification.permission:'unavailable';$('enable-notifications').disabled=permission==='granted'||permission==='denied'||!available;$('enable-notifications').textContent=permission==='granted'?'Browser alerts enabled':permission==='denied'?'Browser alerts blocked':'Enable browser alerts';$('notification-status').textContent=permission==='granted'?'Alerts are enabled for this browser. Keep this page open.':permission==='denied'?'Your browser has blocked alerts. In-page reminders still work.':!available?'Browser alerts are unavailable here. In-page reminders still work.':'In-page reminders already work. Browser alerts are optional.';}
  $('reminders-open').addEventListener('click',()=>{reminderSettings();const list=$('reminder-list');list.replaceChildren();const tasks=dueReminders();if(!tasks.length)list.append(node('p','muted','No reminders are due. Add a due date and reminder to a task.'));for(const t of tasks){const b=node('button','reminder-item',t.text);b.type='button';b.append(node('span','',C.formatDate(t.dueAt,true)+(overdue(t)?' · Overdue':'')));b.addEventListener('click',()=>{$('reminders-dialog').close();openEditor(t.id);});list.append(b);}$('reminders-dialog').showModal();});
  $('enable-notifications').addEventListener('click',async()=>{if(!('Notification'in window))return;try{await Notification.requestPermission();}catch{}reminderSettings();});
  function checkReminders(){updateReminders();const due=dueReminders().filter(t=>prefs.fired[t.id]!==t.dueAt+':'+t.reminderMinutes);if(!due.length)return;for(const t of due)prefs.fired[t.id]=t.dueAt+':'+t.reminderMinutes;preferences();const message=due.length===1?'Reminder: '+due[0].text:due.length+' task reminders are due.';if(!undoAction)notify(message);if('Notification'in window&&Notification.permission==='granted'){try{const n=new Notification('My Task Desk',{body:message,tag:'task-desk-reminder'});n.onclick=()=>{window.focus();n.close();};}catch{}}}
  setInterval(()=>{if(!drag){if(!document.activeElement?.closest('#tasks-container'))render();checkReminders();}},30000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'){if(!drag)render();syncNow();checkReminders();}});
  $('help-open').addEventListener('click',()=>$('help-dialog').showModal());
  if(location.protocol==='file:'){$('download-page').href=location.href;}
  for(const [time,date] of [[$('quick-time'),$('quick-date')],[$('edit-time'),$('edit-date')]])time.addEventListener('change',()=>{if(time.value&&!date.value)date.value=C.dateInput(Date.now());});
  function leaveAccount(){if(ownerId)localStorage.setItem(KEY+'.'+ownerId,JSON.stringify({...state,ownerId}));state=C.normalizeState({schemaVersion:4,tasks:[]});ownerId=null;onlineAccount=null;cloudState='auth';prefs.lastSync=null;prefs.remoteVersions=null;preferences();saveLocal();render();}
  window.TaskDesk={getState:()=>state,leaveAccount,getOwner:()=>ownerId,getPrefs:()=>prefs,savePrefs:preferences,getView:()=>view,visibleTasks,mutate,stamp,render,openEditor,getEditorId:()=>editorId,notify,download,syncNow,setView,resetFilters,isFile,pendingCount,updateSyncLabel,getAccount:()=>onlineAccount};
  saveLocal();render();syncNow();
})();
