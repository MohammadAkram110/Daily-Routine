(function(root,factory){
  const api=factory();root.TaskDeskCloudFactory=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(typeof window!=='undefined'&&window.document)root.TaskDeskCloud=api.createClient({config:root.TASK_DESK_CONFIG,core:root.TaskDeskCore});
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const CONNECTION='taskdesk.independent.connection.v1';
  function checkConfig(raw={}){
    const url=String(raw?.supabaseUrl??'').trim().replace(/\/$/,''),key=String(raw?.supabaseKey??'').trim();
    if(!url&&!key)return null;
    let parsed;try{parsed=new URL(url);}catch{throw new Error('Enter your Supabase project URL, beginning with https://.');}
    if(parsed.protocol!=='https:'||!/^[-a-z0-9]+\.supabase\.co$/.test(parsed.hostname)||parsed.pathname!=='/'||parsed.search||parsed.hash||parsed.username||parsed.password||parsed.port)throw new Error('Use the project URL shown in Supabase, such as https://your-project.supabase.co.');
    if(key.startsWith('sb_secret_'))throw new Error('Use a publishable or anon public key. Never use a secret key.');
    if(key.startsWith('eyJ')){
      try{const part=key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');const payload=JSON.parse(atob(part.padEnd(Math.ceil(part.length/4)*4,'=')));if(payload.role!=='anon')throw new Error('wrong-role');}
      catch{throw new Error('Use the anon public key, not a service-role or user token.');}
    }else if(!/^sb_publishable_[A-Za-z0-9_-]+$/.test(key))throw new Error('Enter a valid publishable or anon public key.');
    return {supabaseUrl:parsed.origin,supabaseKey:key};
  }
  function createClient(options={}){
    const C=options.core??globalThis.TaskDeskCore,clock=options.now??Date.now,fetcher=options.fetch??((...args)=>globalThis.fetch(...args));
    const memory=new Map(),fallback={getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v),removeItem:k=>memory.delete(k)};
    let storage=options.storage;try{storage??=globalThis.localStorage;}catch{}storage??=fallback;
    const read=k=>{try{return JSON.parse(storage.getItem(k)||'null');}catch{return null;}};
    const write=(k,v)=>{try{v===null?storage.removeItem(k):storage.setItem(k,JSON.stringify(v));}catch{throw new Error('Browser saving is unavailable. Enable site storage before signing in.');}};
    let config=null,configError='';try{config=checkConfig(read(CONNECTION)??options.config??{});}catch(e){configError=e.message;}
    const sessionKey=()=>config?'taskdesk.independent.session.'+new URL(config.supabaseUrl).hostname:'';
    let session=config?read(sessionKey()):null,epoch=0,refreshInFlight=null;
    if(!session?.access_token||!session?.refresh_token||!session?.user?.id)session=null;
    const changed=()=>{if(typeof window!=='undefined')window.dispatchEvent(new Event('taskdesk:auth'));};
    const scope=()=>({id:session?.user?.id,epoch});
    function ensureScope(owner){if(!owner?.id||owner.epoch!==epoch||owner.id!==session?.user?.id){const e=new Error('Your account changed. Sign in and retry sync.');e.status=401;throw e;}}
    function acceptSession(data,expectedEpoch){
      if(expectedEpoch!==epoch){const e=new Error('Your account changed. Try signing in again.');e.status=401;throw e;}
      if(!data?.access_token||!data?.refresh_token||!data?.user?.id)throw new Error('The sign-in response was incomplete.');
      session={access_token:data.access_token,refresh_token:data.refresh_token,user:{id:data.user.id,email:data.user.email??''},expires_at:data.expires_at??Math.floor(clock()/1000)+(data.expires_in??3600)};
      write(sessionKey(),session);changed();return session.user;
    }
    async function auth(path,body){
      if(!config)throw new Error('Connect your Supabase project first.');
      const r=await fetcher(config.supabaseUrl+'/auth/v1/'+path,{method:'POST',redirect:'error',headers:{apikey:config.supabaseKey,'Content-Type':'application/json'},body:JSON.stringify(body)});
      let data;try{data=await r.json();}catch{throw new Error('The sign-in service did not return a valid response.');}
      if(!r.ok){const e=new Error(data.msg||data.error_description||data.message||'Sign-in could not finish.');e.status=r.status;throw e;}return data;
    }
    async function token(force=false,owner=scope()){
      ensureScope(owner);
      if(!force&&session.expires_at*1000>clock()+60000)return session.access_token;
      if(!refreshInFlight||refreshInFlight.epoch!==epoch){
        const pending={epoch,promise:null},refresh=session.refresh_token;
        pending.promise=(async()=>{
          try{const data=await auth('token?grant_type=refresh_token',{refresh_token:refresh});ensureScope(owner);acceptSession(data,pending.epoch);return session.access_token;}
          catch(e){if(pending.epoch===epoch&&(e.status===400||e.status===401)){epoch++;session=null;write(sessionKey(),null);changed();}throw e;}
          finally{if(refreshInFlight===pending)refreshInFlight=null;}
        })();refreshInFlight=pending;
      }
      const access=await refreshInFlight.promise;ensureScope(owner);return access;
    }
    async function raw(path,options={},owner=scope(),retry=true){
      ensureScope(owner);const access=await token(false,owner);ensureScope(owner);
      const headers=new Headers(options.headers??{});headers.set('apikey',config.supabaseKey);headers.set('Authorization','Bearer '+access);
      const r=await fetcher(config.supabaseUrl+path,{...options,signal:options.signal??owner.signal,headers,redirect:'error',cache:'no-store'});ensureScope(owner);
      if(r.status===401&&retry){await token(true,owner);return raw(path,options,owner,false);}return r;
    }
    async function json(path,options={},owner=scope()){
      const r=await raw(path,options,owner);let data;try{data=await r.json();}catch{data=null;}ensureScope(owner);
      if(!r.ok){const missing=['42P01','PGRST202','PGRST205'].includes(data?.code);const e=new Error(missing?'Run supabase/setup.sql in your project SQL editor, then try again.':data?.message||data?.error||'The cloud request failed.');e.status=r.status;e.code=data?.code;throw e;}return data;
    }
    const response=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
    const body=object=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(object)});
    const table=name=>'/rest/v1/'+name;
    async function current(owner){
      const rows=await json(table('taskdesk_accounts')+'?select=document,revision&user_id=eq.'+encodeURIComponent(owner.id)+'&limit=1',{},owner);
      return {document:rows[0]?C.normalizeState(rows[0].document):C.normalizeState({schemaVersion:4,tasks:[]}),revision:rows[0]?.revision??0};
    }
    async function save(incoming,owner){
      const document=C.normalizeState(incoming);
      for(let attempt=0;attempt<5;attempt++){
        const previous=await current(owner),merged=C.mergeStates(document,previous.document);
        if(new TextEncoder().encode(JSON.stringify(merged)).length>1500000){const e=new Error('Your cloud list is too large. Export a backup and reduce old records.');e.status=413;throw e;}
        try{const saved=await json('/rest/v1/rpc/taskdesk_save_state',body({p_document:merged,p_expected_revision:previous.revision}),owner);return {document:C.normalizeState(saved.document),revision:saved.revision,backupWarning:false};}
        catch(e){if(e.status!==409&&e.code!=='40001'&&e.code!=='PT409')throw e;}
      }
      const e=new Error('Another device is saving. Your local changes are safe; retry sync.');e.status=409;throw e;
    }
    const validId=id=>/^[-a-zA-Z0-9_]{8,80}$/.test(id);
    async function upload(form,owner){
      const file=form?.get?.('file'),id=form?.get?.('id');
      if(!file||typeof file.arrayBuffer!=='function'||typeof id!=='string'||!validId(id)||file.size>10000000||! /\.(png|jpe?g|webp|gif|pdf|txt|csv|xlsx|docx)$/i.test(file.name)){const e=new Error('Use photos, PDF, TXT, CSV, XLSX, or DOCX up to 10 MB.');e.status=400;throw e;}
      const name=file.name.replace(/[\r\n/\\]/g,'_').slice(0,255);
      const existing=await json(table('taskdesk_files')+'?id=eq.'+encodeURIComponent(id)+'&select=id,name,size',{},owner);
      if(existing.length){if(existing[0].size!==file.size||existing[0].name!==name)throw new Error('This attachment ID is already used by another file.');return {id,uploaded:true};}
      const objectPath=owner.id+'/'+id,r=await raw('/storage/v1/object/taskdesk-files/'+objectPath,{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream','x-upsert':'false'},body:file},owner);
      if(!r.ok&&r.status!==409&&r.status!==400)throw new Error('The attachment could not upload. Check the storage setup and retry.');
      // Interrupted uploads may leave an immutable object without its metadata row.
      if(!r.ok){const probe=await raw('/storage/v1/object/taskdesk-files/'+objectPath,{},owner);if(!probe.ok||Number(probe.headers.get('content-length'))!==file.size)throw new Error('The attachment upload did not finish. Retry with a new file.');}
      await json(table('taskdesk_files'),{...body({id,user_id:owner.id,name,type:file.type||'application/octet-stream',size:file.size,created_at:clock()}),headers:{'Content-Type':'application/json',Prefer:'resolution=ignore-duplicates,return=representation'}},owner);
      return {id,uploaded:true};
    }
    async function file(id,owner){
      if(!validId(id))return response({error:'Attachment not found.'},404);
      const rows=await json(table('taskdesk_files')+'?id=eq.'+encodeURIComponent(id)+'&select=name,type&limit=1',{},owner);
      if(!rows.length)return response({error:'Attachment not found in this account.'},404);
      const r=await raw('/storage/v1/object/taskdesk-files/'+owner.id+'/'+id,{},owner);
      if(!r.ok)return response({error:'Attachment not found.'},404);
      const blob=await r.blob();ensureScope(owner);
      return new Response(blob,{headers:{'Content-Type':rows[0].type,'Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(rows[0].name),'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}});
    }
    async function request(path,options={}){
      try{
        if(!config||!session)return response({error:'Sign in to synchronize your tasks.'},401);
        const owner={...scope(),signal:options.signal},method=options.method??'GET';await token(false,owner);
        if(path==='/api/state'){
          if(method==='GET'){const data=await current(owner);return response({user:{id:owner.id,name:session.user.email},...data});}
          if(method==='POST')return response(await save(JSON.parse(options.body),owner));
          return response({error:'Method not allowed.'},405);
        }
        if(path==='/api/backups'){
          if(method==='GET')return response({backups:await json(table('taskdesk_backups')+'?select=id,label,created_at&order=created_at.desc&limit=30',{},owner)});
          if(method==='POST')return response(await json('/rest/v1/rpc/taskdesk_snapshot',body({p_label:'Saved copy'}),owner));
        }
        if(path.startsWith('/api/backups/')&&method==='GET'){
          const id=decodeURIComponent(path.slice('/api/backups/'.length)),rows=await json(table('taskdesk_backups')+'?id=eq.'+encodeURIComponent(id)+'&select=document,label,created_at&limit=1',{},owner);
          return rows.length?response({document:C.normalizeState(rows[0].document),label:rows[0].label,createdAt:rows[0].created_at}):response({error:'Backup not found.'},404);
        }
        if(path==='/api/files'&&method==='POST')return response(await upload(options.body,owner));
        if(path.startsWith('/api/files/')&&method==='GET')return await file(decodeURIComponent(path.slice('/api/files/'.length)),owner);
        return response({error:'This operation is not available.'},404);
      }catch(e){return response({error:e.message||'Cloud access could not finish.'},e.status??500);}
    }
    return {
      get configured(){return !!config;},get configError(){return configError;},get configuration(){return config?{...config}:null;},get user(){return session?.user??null;},request,
      async signIn(email,password){const expected=++epoch;refreshInFlight=null;const data=await auth('token?grant_type=password',{email:email.trim(),password});return acceptSession(data,expected);},
      async signOut(){
        const previous=session;epoch++;session=null;refreshInFlight=null;if(config)write(sessionKey(),null);changed();
        if(previous&&config){const r=await fetcher(config.supabaseUrl+'/auth/v1/logout',{method:'POST',redirect:'error',headers:{apikey:config.supabaseKey,Authorization:'Bearer '+previous.access_token}});if(!r.ok&&r.status!==401)throw new Error('Signed out locally. The server session could not be closed.');}
      },
      configure(raw){const next=checkConfig(raw);if(!next)throw new Error('Enter both project connection fields.');write(CONNECTION,next);return next;},
      clearConnection(){write(CONNECTION,null);},
      publicConfig(raw){return 'window.TASK_DESK_CONFIG = '+JSON.stringify(checkConfig(raw),null,2)+';\n';}
    };
  }
  return {createClient,checkConfig};
});
