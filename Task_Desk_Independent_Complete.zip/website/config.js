// These are PUBLIC browser connection settings. Both are available in your
// Supabase project's Connect / API settings. Never use a secret/service-role key.
// Leave blank for device-only use, or fill them before uploading the website.
window.TASK_DESK_CONFIG = {
  supabaseUrl: "",
  supabaseKey: ""
};
