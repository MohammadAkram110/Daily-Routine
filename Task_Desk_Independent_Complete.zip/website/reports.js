(() => {
  'use strict';
  const T=window.TaskDesk,C=window.TaskDeskCore,$=id=>document.getElementById(id);
  const current=C.currentShift(T.getState().roster);
  let selectedDate=current?.date??C.dateInput(Date.now());
  let selectedShift=['Morning','Evening','Night'].includes(current?.shift)?current.shift:'';
  let previewStyle='written',search='';
  const make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const button=(text,id,action,cls='secondary-button')=>{const b=make('button',cls,text);b.type='button';if(id)b.id=id;b.addEventListener('click',action);return b;};
  const id=()=>selectedDate+':'+selectedShift;
  const selected=()=>T.getState().reports.find(r=>r.id===id()&&!r.deleted)??C.freshReport(selectedDate,selectedShift);
  const valid=()=>C.validDate(selectedDate)&&['Morning','Evening','Night'].includes(selectedShift);
  const hasContent=r=>C.REPORT_SECTIONS.some(([key])=>r[key].trim())||r.verbalSummary.trim();

  function saveField(key,value){
    if(!valid())return;
    const r={...selected(),[key]:value,ready:false,updatedAt:T.stamp()};
    T.mutate(s=>C.putReport(s,r),null,false);
  }
  function save(ready){
    if(!valid())return;
    const r=selected();
    if(!hasContent(r)){T.notify('Write at least one highlight before saving this report.');$('report-hse').focus();return;}
    T.mutate(s=>C.putReport(s,{...r,ready,updatedAt:T.stamp()}),ready?'Shift report marked ready.':'Shift report saved as a draft.');
  }
  function openReport(report){selectedDate=report.date;selectedShift=report.shift;render();$('report-hse').focus();}
  function field(key,label,rows=4){
    const wrap=make('label','field report-field',label),input=make(rows?'textarea':'input');
    input.id='report-'+key;input.name=key;input.maxLength=['incharge','handoverTo'].includes(key)?150:6000;
    if(rows){input.rows=rows;input.placeholder=key==='verbalSummary'?'Optional: write the main points you want to say at handover.':'Write one point per line. You can also paste points separated by --.';}
    else input.type='text';
    input.addEventListener('input',()=>saveField(key,input.value));wrap.append(input);return wrap;
  }
  function build(){
    const box=$('workspace-panel');box.replaceChildren();
    const head=make('div','workspace-heading'),heading=make('div');
    heading.append(make('span','eyebrow','CAN PLANT · SHIFT COMMUNICATION'),make('h2','','Shift end report'),make('p','muted','Record the major points from your shift, then prepare your handover.'));
    head.append(heading,button('View pending handover',null,()=>T.setView('handover'),'quiet-button'));box.append(head);
    const selectors=make('div','report-selectors');
    const dateLabel=make('label','field','Shift start date'),date=make('input');date.type='date';date.id='report-date';date.required=true;
    date.addEventListener('change',()=>{if(C.validDate(date.value)){selectedDate=date.value;render();}});dateLabel.append(date);
    const shiftLabel=make('label','field','Shift'),shift=make('select');shift.id='report-shift';
    for(const name of ['','Morning','Evening','Night']){const option=make('option','',name||'Choose shift');option.value=name;shift.append(option);}
    shift.addEventListener('change',()=>{selectedShift=shift.value;render();});shiftLabel.append(shift);
    selectors.append(dateLabel,shiftLabel);box.append(selectors,make('p','report-period',''));
    box.querySelector('.report-period').id='report-period';
    const layout=make('div','report-layout'),form=make('form','report-editor');form.id='shift-report-form';form.addEventListener('submit',e=>{e.preventDefault();save(false);});
    const fields=make('fieldset');fields.id='report-fields';const legend=make('legend','sr-only','Shift report details');fields.append(legend);
    const people=make('div','report-people');people.append(field('incharge','Shift incharge',0),field('handoverTo','Handover to (optional)',0));fields.append(people);
    const highlights=make('div','report-highlights');
    for(const [key,label]of C.REPORT_SECTIONS)highlights.append(field(key,label,key==='plant1'?7:4));
    fields.append(highlights);
    const verbal=make('details','report-verbal');verbal.append(make('summary','','Verbal handover notes (optional)'),field('verbalSummary','Short verbal summary',4),make('p','muted','If left blank, the verbal outline uses all the highlight sections.'));
    fields.append(verbal);
    const actions=make('div','report-actions');actions.append(button('Save draft','report-save',()=>save(false)),button('Mark ready','report-ready',()=>save(true),'primary-button'));fields.append(actions);
    form.append(fields,make('p','muted','Edits save automatically. Editing a ready report returns it to Draft.'));
    const saveStatus=make('p','report-save-state');saveStatus.id='report-save-state';saveStatus.setAttribute('role','status');form.append(saveStatus);
    const preview=make('section','report-preview');preview.setAttribute('aria-label','Shift report preview');
    const previewHead=make('div','report-preview-heading');previewHead.append(make('h3','','Ready to communicate'),make('span','report-badge','Draft'));previewHead.querySelector('.report-badge').id='report-status';
    const tabs=make('div','report-preview-tabs');tabs.setAttribute('role','group');tabs.setAttribute('aria-label','Report format');
    tabs.append(button('Written report','report-written',()=>{previewStyle='written';refresh();},'quiet-button'),button('Verbal outline','report-verbal-tab',()=>{previewStyle='verbal';refresh();},'quiet-button'));
    const body=make('pre','report-preview-body');body.id='report-preview-body';body.tabIndex=0;
    const copy=make('div','report-actions');copy.append(button('Copy written','report-copy-written',()=>copyReport('written'),'primary-button'),button('Copy verbal','report-copy-verbal',()=>copyReport('verbal')),button('Download .txt','report-download',downloadReport),button('Print / PDF','report-print-button',printReport));
    preview.append(previewHead,tabs,body,copy,make('p','muted','Copy or print the report, then share it through your usual channel. Blank sections remain “Not entered”.'));
    layout.append(form,preview);box.append(layout);
    const history=make('section','report-history');history.setAttribute('aria-label','Saved shift reports');
    const historyHead=make('div','report-history-heading');historyHead.append(make('h3','','Saved reports'));
    const searchLabel=make('label','field','Find a saved report'),input=make('input');input.type='search';input.id='report-search';input.placeholder='Date, shift, equipment tag, or text';input.value=search;
    input.addEventListener('input',()=>{search=input.value;renderHistory();});searchLabel.append(input);historyHead.append(searchLabel);
    const list=make('div','report-history-list');list.id='report-history-list';history.append(historyHead,list);box.append(history);
  }
  function refresh(){
    const enabled=valid(),r=selected(),w=enabled?C.shiftWindow(r):null;
    $('report-date').value=selectedDate;$('report-shift').value=selectedShift;$('report-fields').disabled=!enabled;
    $('report-period').textContent=w?C.formatDate(w.start,true)+' → '+C.formatDate(w.end,true)+' · Pakistan time': 'Choose the date your shift starts and select Morning, Evening, or Night.';
    for(const key of C.REPORT_FIELDS){const input=$('report-'+key);if(input!==document.activeElement)input.value=enabled?r[key]:'';}
    const saved=enabled&&T.getState().reports.some(x=>x.id===r.id&&!x.deleted);
    $('report-status').textContent=r.ready?'Ready':'Draft';$('report-status').classList.toggle('is-ready',r.ready);
    $('report-save-state').textContent=saved?'Saved on this device · '+C.formatDate(r.updatedAt,true):enabled?'Start writing to save a report for this shift.':'No shift selected.';
    $('report-preview-body').textContent=enabled?C.reportText(r,previewStyle):'Your report preview will appear here after you choose a shift.';
    for(const key of ['written','verbal'])$(key==='written'?'report-written':'report-verbal-tab').setAttribute('aria-pressed',String(previewStyle===key));
    for(const key of ['copy-written','copy-verbal','download','print-button'])$('report-'+key).disabled=!enabled||!hasContent(r);
    renderHistory();
  }
  function renderHistory(){
    const list=$('report-history-list');if(!list)return;list.replaceChildren();
    const query=search.trim().toLocaleLowerCase(),reports=T.getState().reports.filter(r=>!r.deleted&&(!query||[r.date,C.formatDate(C.fromInputs(r.date,'00:00')),r.shift,...C.REPORT_FIELDS.map(k=>r[k])].join(' ').toLocaleLowerCase().includes(query))).sort((a,b)=>b.date.localeCompare(a.date)||C.shiftWindow(b).start-C.shiftWindow(a).start);
    if(!reports.length){list.append(make('p','muted',query?'No saved reports match your search.':'Your saved shift reports will appear here.'));return;}
    for(const r of reports.slice(0,30)){
      const row=button('',null,()=>openReport(r),'report-history-item');row.setAttribute('aria-label','Open '+C.formatDate(C.fromInputs(r.date,'00:00'))+' '+r.shift+' report');
      row.append(make('strong','',C.formatDate(C.fromInputs(r.date,'00:00'))+' · '+r.shift),make('span','report-badge'+(r.ready?' is-ready':''),r.ready?'Ready':'Draft'),make('small','',r.incharge||'Shift end report'));
      if(r.id===id())row.setAttribute('aria-current','true');list.append(row);
    }
    if(reports.length>30)list.append(make('p','muted','Showing the latest 30 matches. Search by date or shift to find an older report.'));
  }
  function render(){if(T.getView()!=='reports')return;if(!$('shift-report-form'))build();refresh();}
  function text(style='written'){if(!valid()||!hasContent(selected()))return null;return C.reportText(selected(),style);}
  async function copyReport(style){const value=text(style);if(!value)return;try{await navigator.clipboard.writeText(value);T.notify((style==='verbal'?'Verbal outline':'Written report')+' copied.');}catch{showCopy(value);}}
  function showCopy(value){
    let dialog=$('report-copy-dialog');
    if(!dialog){dialog=make('dialog');dialog.id='report-copy-dialog';dialog.setAttribute('aria-labelledby','report-copy-title');const top=make('div','dialog-top'),title=make('h2','','Copy your report');title.id='report-copy-title';top.append(title,button('Close',null,()=>dialog.close(),'quiet-button'));const label=make('label','field','Select and copy this text'),area=make('textarea');area.id='report-copy-text';area.rows=18;area.readOnly=true;label.append(area);dialog.append(top,label);document.body.append(dialog);}
    $('report-copy-text').value=value;dialog.showModal();$('report-copy-text').focus();$('report-copy-text').select();
  }
  function downloadReport(){const value=text();if(value)T.download(value,'CAN_Shift_Report_'+selectedDate+'_'+selectedShift+'.txt','text/plain;charset=utf-8');}
  function printReport(){const value=text();if(!value)return;let page=$('report-print');if(!page){page=make('article');page.id='report-print';document.body.append(page);}page.replaceChildren(make('pre','',value));document.body.classList.add('printing-report');window.print();}
  window.addEventListener('afterprint',()=>document.body.classList.remove('printing-report'));
  window.addEventListener('taskdesk:render',()=>{if(T.getView()==='reports')render();});
  window.TaskDeskReports={render};
})();
