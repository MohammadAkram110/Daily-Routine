/* Offline application shell only. Account/API responses are never cached here.
   Change VERSION whenever replacing the website's source files. */
const VERSION='taskdesk-independent-20261030-1';
const ASSETS=['./','index.html','styles.css?v=5','enhancements.css?v=5','reports.css?v=5','cloud.css?v=1','config.js?v=1','core.js?v=5','cloud.js?v=1','app.js?v=5','extras.js?v=5','reports.js?v=5','cloud-ui.js?v=1','manifest.webmanifest','icon.svg'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(VERSION).then(cache=>cache.addAll(ASSETS)));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('taskdesk-independent-')&&key!==VERSION).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin||!ASSETS.some(path=>new URL(path,self.registration.scope).href===url.href))return;
  // Fetch new files first. Fall back to the cached shell if the network is down.
  event.respondWith(fetch(event.request).then(async response=>{if(response.ok){const cache=await caches.open(VERSION);await cache.put(event.request,response.clone());}return response;}).catch(()=>caches.match(event.request).then(cached=>cached||Response.error())));
});
