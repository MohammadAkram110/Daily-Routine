(function (root, factory) {
  const api = factory();
  // Server bundles use a CommonJS wrapper, while routes read this shared API.
  root.TaskDeskCore = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const STATUSES = ['pending','in-progress','waiting','completed'];
  const PRIORITIES = ['critical','high','normal','low'];
  const CATEGORIES = ['Work','Personal'];
  const SHIFTS = ['','Morning','Evening','Night','Off','Leave'];
  const AREAS = ['','Ground Floor','AN/ANC','LGU','Granulation','Cooling and Coating','Screening and Crushing','Operation and Scrubbing','Other'];
  const REPORT_SECTIONS = [['hse','HSE/SCD Highlights'],['lab','Lab Highlights'],['plant1','Plant Highlights-1'],['plant2','Plant Highlights-2'],['plant3','Plant Highlights-3'],['pending','Pending work / next shift']];
  const REPORT_FIELDS = [...REPORT_SECTIONS.map(([key])=>key),'verbalSummary','incharge','handoverTo'];
  const labels = {pending:'Pending','in-progress':'In Progress',waiting:'Waiting',completed:'Completed'};
  const fields = ['area','equipment','assignedBy','responsible','department','contact','shift','mwr','notes','closingComment','handover'];
  const offset = 5 * 60 * 60 * 1000;
  const uuid = () => globalThis.crypto?.randomUUID?.() || Date.now().toString(36)+Math.random().toString(36).slice(2);
  const active = (tasks) => tasks.filter(t=>!t.deleted).sort((a,b)=>a.order-b.order || a.id.localeCompare(b.id));
  const pad = n=>String(n).padStart(2,'0');
  function parts(ms) { const d = new Date(ms+offset); return {year:d.getUTCFullYear(),month:d.getUTCMonth(),day:d.getUTCDate(),hours:d.getUTCHours(),minutes:d.getUTCMinutes()}; }
  function dateInput(ms) {if(ms===null||ms===undefined)return '';const p=parts(ms);return `${p.year}-${pad(p.month+1)}-${pad(p.day)}`;}
  function timeInput(ms) {if(ms===null||ms===undefined)return '';const p=parts(ms);return `${pad(p.hours)}:${pad(p.minutes)}`;}
  function fromInputs(date,time) {return date ? Date.parse(date+'T'+(time||'23:59')+':00+05:00') : null;}
  function formatDate(ms, includeTime = false) {if(ms===null||ms===undefined)return 'No deadline';const p=parts(ms);const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return `${pad(p.day)}-${months[p.month]}-${p.year}`+(includeTime?` · ${pad(p.hours)}:${pad(p.minutes)}`:'');}
  function freshTask(data={},now=Date.now(),order=0) {
    const t={id:uuid(),text:'',status:'pending',priority:'normal',category:'Work',dueAt:null,reminderMinutes:15,repeat:null,seriesId:'',occurrence:0,createdAt:now,updatedAt:now,completedAt:null,deleted:false,order,history:[],subtasks:[],attachments:[],color:'',dutyDate:'',mwrStatus:'none',...Object.fromEntries(fields.map(f=>[f,''])),...data};
    if(!t.seriesId)t.seriesId=t.id;
    return t;
  }
  function validateTask(raw,legacy=false) {
    if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('A task is not valid.');
    const id=raw.id;
    if(typeof id!=='string'||!id||id.length>180)throw new Error('A task ID is not valid.');
    if(typeof raw.text!=='string'||!raw.text.trim()||raw.text.length>500)throw new Error('Each task needs a description of 1–500 characters.');
    const t=freshTask({},0,0);t.id=id;t.text=raw.text.trim();
    if(legacy&&typeof raw.completed!=='boolean')throw new Error('A task status is not valid.');
    t.status=legacy?(raw.completed?'completed':'pending'):raw.status;
    if(!STATUSES.includes(t.status))throw new Error('A task status is not valid.');
    t.priority=raw.priority??'normal';t.category=raw.category??'Work';
    if(!PRIORITIES.includes(t.priority)||!CATEGORIES.includes(t.category))throw new Error('A priority or category is not valid.');
    for(const field of fields){const v=raw[field]??'';if(typeof v!=='string'||v.length>6000)throw new Error('A task detail is too long or not valid.');t[field]=v;}
    if(!SHIFTS.includes(t.shift))throw new Error('A shift is not valid.');
    for(const f of ['createdAt','updatedAt','order']){const v=raw[f]??(f==='updatedAt'?raw.createdAt:0);if(typeof v!=='number'||!Number.isFinite(v)||f!=='order'&&Math.abs(v)>8.64e15)throw new Error('A task date or position is not valid.');t[f]=v;}
    for(const f of ['dueAt','completedAt']){const v=raw[f]??null;if(v!==null&&(typeof v!=='number'||!Number.isFinite(v)||Math.abs(v)>8.64e15))throw new Error('A task date is not valid.');t[f]=v;}
    t.deleted=raw.deleted===true;
    const lead=raw.reminderMinutes??15;if(![-1,0,5,15,30,60,1440].includes(lead))throw new Error('A reminder is not valid.');t.reminderMinutes=lead;
    if(raw.repeat){const r=raw.repeat;if(!Number.isInteger(r.every)||r.every<1||r.every>365||!['day','week','month','year'].includes(r.unit)||!['schedule','completion'].includes(r.from))throw new Error('A repeat schedule is not valid.');t.repeat={every:r.every,unit:r.unit,from:r.from,anchorDay:Number.isInteger(r.anchorDay)?Math.min(31,Math.max(1,r.anchorDay)):parts(t.dueAt??t.createdAt).day};}else t.repeat=null;
    t.seriesId=typeof raw.seriesId==='string'&&raw.seriesId.length<160?raw.seriesId:id;
    t.occurrence=Number.isInteger(raw.occurrence)&&raw.occurrence>=0?raw.occurrence:0;
    if(raw.history!==undefined&&!Array.isArray(raw.history))throw new Error('Task history is not valid.');
    t.history=(raw.history??[]).slice(-100).map(h=>{if(!h||!Number.isFinite(h.at)||typeof h.action!=='string'||h.action.length>200||typeof(h.note??'')!=='string'||(h.note??'').length>6000)throw new Error('Task history is not valid.');return{at:h.at,action:h.action,note:h.note??''};});
    t.color=raw.color??'';if(typeof t.color!=='string'||t.color&&!/^#[0-9a-fA-F]{6}$/.test(t.color))throw new Error('Invalid task colour.');
    t.dutyDate=raw.dutyDate??'';if(t.dutyDate&&!validDate(t.dutyDate))throw new Error('Invalid duty date.');
    t.mwrStatus=raw.mwrStatus??(t.mwr?'raised':'none');if(!['none','to-raise','raised','closed'].includes(t.mwrStatus))throw new Error('Invalid MWR status.');
    if(raw.subtasks!==undefined&&(!Array.isArray(raw.subtasks)||raw.subtasks.length>100))throw new Error('A task can have up to 100 steps.');
    const ids=new Set();t.subtasks=(raw.subtasks??[]).map(x=>{if(!x||typeof x.id!=='string'||!x.id||x.id.length>100||ids.has(x.id)||typeof x.text!=='string'||!x.text.trim()||x.text.length>500||typeof x.done!=='boolean')throw new Error('Invalid checklist step.');ids.add(x.id);return{id:x.id,text:x.text.trim(),done:x.done};});
    if(raw.attachments!==undefined&&(!Array.isArray(raw.attachments)||raw.attachments.length>20))throw new Error('A task can have up to 20 attachments.');
    const files=new Set();t.attachments=(raw.attachments??[]).map(f=>{if(!f||typeof f.id!=='string'||!/^[-a-zA-Z0-9_]{8,80}$/.test(f.id)||files.has(f.id)||typeof f.name!=='string'||!f.name||f.name.length>255||typeof f.type!=='string'||f.type.length>150||!Number.isInteger(f.size)||f.size<0||f.size>10000000||!Number.isFinite(f.createdAt))throw new Error('Invalid attachment.');files.add(f.id);return{id:f.id,name:f.name,type:f.type,size:f.size,createdAt:f.createdAt,uploaded:f.uploaded===true};});
    return t;
  }
  function validDate(s){return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&dateInput(fromInputs(s,'00:00'))===s;}
  function normalizeRoster(items=[]){if(!Array.isArray(items)||items.length>4000)throw new Error('Invalid roster.');const ids=new Set();return items.map(r=>{if(!r||!validDate(r.date)||r.id!==r.date||ids.has(r.id)||!SHIFTS.slice(1).includes(r.shift)||typeof r.note!=='string'||r.note.length>2000||!Number.isFinite(r.updatedAt))throw new Error('Invalid duty.');ids.add(r.id);return{id:r.id,date:r.date,shift:r.shift,note:r.note,updatedAt:r.updatedAt,deleted:r.deleted===true};});}
  function shiftWindow(r){if(!r||r.deleted||!['Morning','Evening','Night'].includes(r.shift))return null;const start=fromInputs(r.date,{Morning:'06:00',Evening:'14:00',Night:'22:00'}[r.shift]);return{...r,start,end:start+28800000};}
  function currentShift(roster,now=Date.now()){const current=roster.map(shiftWindow).find(w=>w&&now>=w.start&&now<w.end);if(current)return current;const r=roster.find(r=>!r.deleted&&r.date===dateInput(now)&&['Off','Leave'].includes(r.shift));return r?{...r,start:fromInputs(r.date,'00:00'),end:fromInputs(r.date,'00:00')+86400000}:null;}
  function nextShift(roster,now=Date.now()){return roster.map(shiftWindow).filter(w=>w&&w.start>now).sort((a,b)=>a.start-b.start)[0]??null;}
  function freshReport(date,shift,now=Date.now()) {return {id:date+':'+shift,date,shift,createdAt:now,updatedAt:now,ready:false,deleted:false,...Object.fromEntries(REPORT_FIELDS.map(key=>[key,'']))};}
  function normalizeReports(items=[]) {
    if(!Array.isArray(items)||items.length>4000)throw new Error('A backup can contain up to 4,000 shift reports.');
    const seen=new Set();
    return items.map(raw=>{
      if(!raw||!validDate(raw.date)||!['Morning','Evening','Night'].includes(raw.shift)||raw.id!==raw.date+':'+raw.shift||seen.has(raw.id))throw new Error('A shift report date or shift is not valid.');
      seen.add(raw.id);const r=freshReport(raw.date,raw.shift,0);
      for(const key of REPORT_FIELDS){const value=raw[key]??'';if(typeof value!=='string'||value.length>(['incharge','handoverTo'].includes(key)?150:6000))throw new Error('A shift report field is too long or not valid.');r[key]=value;}
      for(const key of ['createdAt','updatedAt']){if(!Number.isFinite(raw[key])||Math.abs(raw[key])>8.64e15)throw new Error('A shift report save date is not valid.');r[key]=raw[key];}
      if(raw.ready!==undefined&&typeof raw.ready!=='boolean'||raw.deleted!==undefined&&typeof raw.deleted!=='boolean')throw new Error('A shift report status is not valid.');
      r.ready=raw.ready===true;r.deleted=raw.deleted===true;return r;
    });
  }
  function mergeReports(a=[],b=[]) {const map=new Map();for(const r of [...a,...b]){const old=map.get(r.id);if(!old||r.updatedAt>old.updatedAt||r.updatedAt===old.updatedAt&&(r.deleted&&!old.deleted||r.deleted===old.deleted&&JSON.stringify(r)>JSON.stringify(old)))map.set(r.id,r);}return [...map.values()].sort((a,b)=>a.id.localeCompare(b.id));}
  function putReport(state,report) {const [checked]=normalizeReports([report]);return {...state,schemaVersion:4,reports:[...(state.reports??[]).filter(r=>r.id!==checked.id),checked]};}
  function reportLines(text) {return String(text??'').replace(/(?:^|\s)--(?=\S)/g,'\n').split(/\r?\n/).map(s=>s.replace(/^\s*[•]\s*/, '').trim()).filter(Boolean);}
  function reportText(report,style='written') {
    const r=normalizeReports([report])[0],w=shiftWindow(r),header=['CAN PLANT — SHIFT END REPORT',formatDate(fromInputs(r.date,'00:00'))+' · '+r.shift+' shift',formatDate(w.start,true)+' → '+formatDate(w.end,true)+' (Pakistan time)','Status: '+(r.ready?'Ready':'Draft'),r.incharge?'Shift incharge: '+r.incharge:'',r.handoverTo?'Handover to: '+r.handoverTo:''].filter(Boolean);
    if(style==='verbal'&&r.verbalSummary.trim())return [...header,'','VERBAL HANDOVER NOTES',...reportLines(r.verbalSummary).map(s=>'• '+s),...(r.pending.trim()?['','Pending work / next shift',...reportLines(r.pending).map(s=>'• '+s)]:[])].join('\n');
    return [...header,...(style==='verbal'?['','VERBAL HANDOVER OUTLINE']:[]),...REPORT_SECTIONS.flatMap(([key,label])=>['',label,...(reportLines(r[key]).length?reportLines(r[key]).map(s=>'• '+s):['Not entered'])])].join('\n');
  }
  function normalizeState(raw) {
    const legacy=Array.isArray(raw);const items=legacy?raw:raw?.tasks;
    if(!legacy&&![2,3,4].includes(raw?.schemaVersion))throw new Error('This is not a supported Task Desk backup.');
    if(!Array.isArray(items)||items.length>10000)throw new Error('A backup must contain a task list with at most 10,000 records.');
    const seen=new Set();
    const tasks=items.map((item,i)=>{const t=validateTask(legacy?{...item,order:i}:item,legacy);if(seen.has(t.id))throw new Error('The backup contains duplicate task IDs.');seen.add(t.id);return t;});
    const settings=legacy?{}:raw.settings??{};if(!settings||Array.isArray(settings)||typeof settings!=='object'||settings.updatedAt!==undefined&&!Number.isFinite(settings.updatedAt)||settings.backgroundReminders!==undefined&&typeof settings.backgroundReminders!=='boolean')throw new Error('Invalid task settings.');return {schemaVersion:4,tasks,roster:normalizeRoster(legacy?[]:raw.roster??[]),reports:normalizeReports(legacy?[]:raw.reports??[]),settings:{updatedAt:settings.updatedAt??0,backgroundReminders:settings.backgroundReminders??true}};
  }
  function mergeStates(a,b) {
    const map=new Map();
    for(const t of [...a.tasks,...b.tasks]){const old=map.get(t.id);if(!old||t.updatedAt>old.updatedAt||(t.updatedAt===old.updatedAt&&(t.deleted&&!old.deleted||t.deleted===old.deleted&&JSON.stringify(t)>JSON.stringify(old))))map.set(t.id,t);}
    const rows=new Map();for(const r of [...(a.roster??[]),...(b.roster??[])]){const old=rows.get(r.id);if(!old||r.updatedAt>old.updatedAt||r.updatedAt===old.updatedAt&&JSON.stringify(r)>JSON.stringify(old))rows.set(r.id,r);}const x=a.settings??{updatedAt:0,backgroundReminders:true},y=b.settings??{updatedAt:0,backgroundReminders:true};return{schemaVersion:4,tasks:[...map.values()].sort((a,b)=>a.id.localeCompare(b.id)),roster:[...rows.values()].sort((a,b)=>a.date.localeCompare(b.date)),reports:mergeReports(a.reports,b.reports),settings:x.updatedAt>y.updatedAt?x:y};
  }
  function log(task,action,now,note='') {return{...task,updatedAt:now,history:[...task.history,{at:now,action,note}].slice(-100)};}
  function addPeriod(ms,repeat,n=1) {
    const p=parts(ms),d=new Date(ms+offset);
    if(repeat.unit==='day'||repeat.unit==='week')d.setUTCDate(p.day+repeat.every*n*(repeat.unit==='week'?7:1));
    else{const total=p.year*12+p.month+(repeat.unit==='year'?12:1)*repeat.every*n;const y=Math.floor(total/12),m=total%12;const day=Math.min(repeat.anchorDay||p.day,new Date(Date.UTC(y,m+1,0)).getUTCDate());d.setUTCFullYear(y,m,day);}
    return d.getTime()-offset;
  }
  function nextDueAt(task,now) {
    const r=task.repeat;if(!r)return null;
    if(r.from==='completion')return addPeriod(now,{...r,anchorDay:parts(now).day});
    const base=task.dueAt??now;
    let n=1;
    if(base<now&&(r.unit==='day'||r.unit==='week'))n=Math.max(1,Math.floor((now-base)/(86400000*r.every*(r.unit==='week'?7:1)))+1);
    else if(base<now){const a=parts(base),b=parts(now);n=Math.max(1,Math.floor(((b.year-a.year)*12+b.month-a.month)/(r.every*(r.unit==='year'?12:1))));}
    let next=addPeriod(base,r,n);while(next<=now){n++;next=addPeriod(base,r,n);}return next;
  }
  function changeStatus(state,id,status,now) {
    const old=state.tasks.find(t=>t.id===id&&!t.deleted);if(!old||old.status===status)return state;
    if(!STATUSES.includes(status))throw new Error('Invalid status');
    const changed=log({...old,status,completedAt:status==='completed'?now:null},status==='completed'?'Completed':`Moved to ${labels[status]}`,now,status==='completed'?old.closingComment:'');
    const tasks=state.tasks.map(t=>t.id===id?changed:t);
    if(status==='completed'&&old.repeat){const nextId=old.seriesId+':'+(old.occurrence+1);if(!tasks.some(t=>t.id===nextId)){
      const next=freshTask({...old,id:nextId,text:old.text,status:'pending',completedAt:null,closingComment:'',subtasks:(old.subtasks??[]).map(x=>({...x,done:false})),dutyDate:'',dueAt:nextDueAt(old,now),occurrence:old.occurrence+1,createdAt:now,updatedAt:now,history:[{at:now,action:'Recurring task created',note:''}],order:Math.max(0,...tasks.map(t=>t.order))+1},now);tasks.push(next);
    }}
    return{...state,schemaVersion:4,tasks};
  }
  function reorderTask(state,id,targetId,after,status,now) {
    let result=status?changeStatus(state,id,status,now):state;
    const moving=result.tasks.find(t=>t.id===id&&!t.deleted);if(!moving)return result;
    const ordered=active(result.tasks).filter(t=>t.id!==id);
    let index=ordered.findIndex(t=>t.id===targetId);
    if(index<0){const candidates=ordered.filter(t=>!status||t.status===status);index=candidates.length?ordered.indexOf(candidates[candidates.length-1])+1:ordered.length;}else if(after)index++;
    const before=ordered[index-1]?.order, next=ordered[index]?.order;
    const order=before===undefined?(next??1)-1:next===undefined?before+1:(before+next)/2;
    result={...result,schemaVersion:4,tasks:result.tasks.map(t=>t.id===id?log({...t,order},'Order changed',now):t)};
    if(!Number.isFinite(order)||(before!==undefined&&next!==undefined&&next-before<1e-8)){const ids=active(result.tasks).map(t=>t.id);result.tasks=result.tasks.map(t=>t.deleted?t:{...t,order:ids.indexOf(t.id),updatedAt:now});}
    return result;
  }
  const xml = value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c])).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'');
  function zipFiles(files) {
    const encoder=new TextEncoder(),chunks=[],central=[];let at=0;
    const crc=(bytes)=>{let c=0xffffffff;for(const b of bytes){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;};
    const buffer=(size)=>{const b=new Uint8Array(size);return{b,v:new DataView(b.buffer)};};
    for(const [path,text]of Object.entries(files)){const name=encoder.encode(path),data=text instanceof Uint8Array?text:encoder.encode(text),checksum=crc(data),h=buffer(30);h.v.setUint32(0,0x04034b50,true);h.v.setUint16(4,20,true);h.v.setUint16(6,2048,true);h.v.setUint32(14,checksum,true);h.v.setUint32(18,data.length,true);h.v.setUint32(22,data.length,true);h.v.setUint16(26,name.length,true);chunks.push(h.b,name,data);const c=buffer(46);c.v.setUint32(0,0x02014b50,true);c.v.setUint16(4,20,true);c.v.setUint16(6,20,true);c.v.setUint16(8,2048,true);c.v.setUint32(16,checksum,true);c.v.setUint32(20,data.length,true);c.v.setUint32(24,data.length,true);c.v.setUint16(28,name.length,true);c.v.setUint32(42,at,true);central.push(c.b,name);at+=30+name.length+data.length;}
    const centralSize=central.reduce((n,x)=>n+x.length,0),end=buffer(22);end.v.setUint32(0,0x06054b50,true);end.v.setUint16(8,Object.keys(files).length,true);end.v.setUint16(10,Object.keys(files).length,true);end.v.setUint32(12,centralSize,true);end.v.setUint32(16,at,true);chunks.push(...central,end.b);const output=new Uint8Array(chunks.reduce((n,x)=>n+x.length,0));let pos=0;for(const chunk of chunks){output.set(chunk,pos);pos+=chunk.length;}return output;
  }
  function unzipStored(bytes){if(!(bytes instanceof Uint8Array)||bytes.length>100100000)throw new Error('Choose an archive up to 100 MB.');const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),files={},decoder=new TextDecoder();let at=0;while(at+4<=bytes.length&&v.getUint32(at,true)===0x04034b50){if(at+30>bytes.length||v.getUint16(at+8,true)!==0||v.getUint16(at+6,true)&9)throw new Error('Choose a ZIP created by Task Desk.');const size=v.getUint32(at+18,true),len=v.getUint16(at+26,true),extra=v.getUint16(at+28,true),start=at+30+len+extra;if(size>10000000||start+size>bytes.length)throw new Error('Invalid attachment archive.');const name=decoder.decode(bytes.slice(at+30,at+30+len));if(name.includes('/')||name.includes('\\')||Object.hasOwn(files,name))throw new Error('Invalid attachment name.');const data=bytes.slice(start,start+size);let crc=0xffffffff;for(const b of data){crc^=b;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}if(((crc^0xffffffff)>>>0)!==v.getUint32(at+14,true))throw new Error('An attachment is damaged.');files[name]=data;at=start+size;}if(!Object.keys(files).length||at+4>bytes.length||v.getUint32(at,true)!==0x02014b50)throw new Error('Choose a ZIP created by Task Desk.');return files;}
  function makeXlsx(state) {
    const rows=[['Order','Task','Status','Priority','Category','Due (Pakistan time)','Area','Equipment tag','Assigned by','Responsible person','Department','Contact','Shift','MWR number','Notes','Closing comment','Handover','Completed at','Repeat','Reminder (minutes)','Checklist','Duty date','MWR status','Attachments','Colour']];
    const history=[['Task','Action','Date & time (Pakistan)','Comment']];
    active(state.tasks).forEach((t,i)=>{rows.push([i+1,t.text,labels[t.status],t.priority,t.category,t.dueAt?formatDate(t.dueAt,true):'',...fields.map(f=>t[f]),t.completedAt?formatDate(t.completedAt,true):'',t.repeat?`Every ${t.repeat.every} ${t.repeat.unit}(s), from ${t.repeat.from}`:'',t.reminderMinutes<0?'Off':t.reminderMinutes,(t.subtasks??[]).map(s=>(s.done?'[x] ':'[ ] ')+s.text).join('\n'),t.dutyDate?formatDate(fromInputs(t.dutyDate,'00:00')):'',t.mwrStatus,(t.attachments??[]).map(f=>f.name).join('; '),t.color]);for(const h of t.history)history.push([t.text,h.action,formatDate(h.at,true),h.note]);});
    const sheet=data=>'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetData>'+data.map((row,i)=>'<row r="'+(i+1)+'">'+row.map(v=>'<c t="inlineStr"><is><t xml:space="preserve">'+xml(v)+'</t></is></c>').join('')+'</row>').join('')+'</sheetData><autoFilter ref="A1:'+String.fromCharCode(64+data[0].length)+'1"/></worksheet>';
    const files={
      '[Content_Types].xml':'<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
      '_rels/.rels':'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
      'xl/workbook.xml':'<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Tasks" sheetId="1" r:id="rId1"/><sheet name="History" sheetId="2" r:id="rId2"/></sheets></workbook>',
      'xl/_rels/workbook.xml.rels':'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>',
      'xl/worksheets/sheet1.xml':sheet(rows),'xl/worksheets/sheet2.xml':sheet(history)
    };
    const reports=[['Shift start date','Shift','Start (Pakistan)','End (Pakistan)','Status','Shift incharge','Handover to',...REPORT_SECTIONS.map(([,label])=>label),'Verbal handover notes','Saved (Pakistan)']];
    for(const r of (state.reports??[]).filter(r=>!r.deleted).sort((a,b)=>b.id.localeCompare(a.id))){const w=shiftWindow(r);reports.push([formatDate(fromInputs(r.date,'00:00')),r.shift,formatDate(w.start,true),formatDate(w.end,true),r.ready?'Ready':'Draft',r.incharge,r.handoverTo,...REPORT_SECTIONS.map(([key])=>r[key]),r.verbalSummary,formatDate(r.updatedAt,true)]);}
    files['[Content_Types].xml']=files['[Content_Types].xml'].replace('</Types>','<Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
    files['xl/workbook.xml']=files['xl/workbook.xml'].replace('</sheets>','<sheet name="Shift Reports" sheetId="3" r:id="rId3"/></sheets>');
    files['xl/_rels/workbook.xml.rels']=files['xl/_rels/workbook.xml.rels'].replace('</Relationships>','<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/></Relationships>');
    files['xl/worksheets/sheet3.xml']=sheet(reports);return zipFiles(files);
  }
  return{STATUSES,PRIORITIES,CATEGORIES,SHIFTS,AREAS,REPORT_SECTIONS,REPORT_FIELDS,labels,fields,uuid,active,dateInput,timeInput,fromInputs,formatDate,freshTask,validateTask,normalizeState,mergeStates,log,nextDueAt,changeStatus,reorderTask,makeXlsx,zipFiles,unzipStored,validDate,normalizeRoster,shiftWindow,currentShift,nextShift,freshReport,normalizeReports,mergeReports,putReport,reportLines,reportText};
});
